package net.mangoreggie.blockarmor.mixin;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Final;

import net.minecraft.world.item.equipment.trim.ArmorTrim;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.component.DyedItemColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.component.DataComponents;
import net.minecraft.client.resources.model.EquipmentClientInfo;
import net.minecraft.client.resources.model.EquipmentAssetManager;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.entity.layers.EquipmentLayerRenderer;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.Sheets;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.model.Model;

import net.mangoreggie.blockarmor.init.BlockArmorModArmorModels;

import java.util.function.Function;
import java.util.List;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

@Mixin(EquipmentLayerRenderer.class)
public abstract class EquipmentLayerRendererMixin {
	@Shadow
	@Final
	private EquipmentAssetManager equipmentAssets;
	@Shadow
	@Final
	private Function<EquipmentLayerRenderer.LayerTextureKey, ResourceLocation> layerTextureLookup;
	@Shadow
	@Final
	private Function<EquipmentLayerRenderer.TrimSpriteKey, TextureAtlasSprite> trimSpriteLookup;

	@Shadow
	private static int getColorForLayer(EquipmentClientInfo.Layer layer, int i) {
		return 0;
	}

	@Inject(method = "Lnet/minecraft/client/renderer/entity/layers/EquipmentLayerRenderer;renderLayers(Lnet/minecraft/client/resources/model/EquipmentClientInfo$LayerType;Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/client/model/Model;Lnet/minecraft/world/item/ItemStack;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/resources/ResourceLocation;)V", at = @At("HEAD"), cancellable = true)
	public void renderLayers(EquipmentClientInfo.LayerType layerType, ResourceKey<EquipmentAsset> resourceKey, Model model, ItemStack itemStack, PoseStack poseStack, MultiBufferSource multiBufferSource, int i, ResourceLocation resourceLocation,
			CallbackInfo ci) {
		if (BlockArmorModArmorModels.ARMOR_MODELS.containsKey(itemStack.getItem())) {
			BlockArmorModArmorModels.ArmorModel armorModel = BlockArmorModArmorModels.ARMOR_MODELS.get(itemStack.getItem());
			if (armorModel.getHumanoidArmorModel(itemStack, layerType, model) != null)
				model = armorModel.getGenericArmorModel(itemStack, layerType, model);
			List<EquipmentClientInfo.Layer> list = this.equipmentAssets.get(resourceKey).getLayers(layerType);
			if (list.isEmpty()) {
				ci.cancel();
			}
			int j = DyedItemColor.getOrDefault(itemStack, 0);
			boolean bl = itemStack.hasFoil();
			for (EquipmentClientInfo.Layer layer : list) {
				int k = getColorForLayer(layer, j);
				if (k == 0)
					continue;
				ResourceLocation resourceLocation2 = layer.usePlayerTexture() && resourceLocation != null ? resourceLocation : this.layerTextureLookup.apply(new EquipmentLayerRenderer.LayerTextureKey(layerType, layer));
				resourceLocation2 = armorModel.getArmorTexture(itemStack, layerType, layer, resourceLocation2);
				VertexConsumer vertexConsumer = ItemRenderer.getArmorFoilBuffer(multiBufferSource, RenderType.armorCutoutNoCull(resourceLocation2), bl);
				model.renderToBuffer(poseStack, vertexConsumer, i, OverlayTexture.NO_OVERLAY, k);
				bl = false;
			}
			ArmorTrim armorTrim = itemStack.get(DataComponents.TRIM);
			if (armorTrim != null) {
				TextureAtlasSprite textureAtlasSprite = this.trimSpriteLookup.apply(new EquipmentLayerRenderer.TrimSpriteKey(armorTrim, layerType, resourceKey));
				VertexConsumer vertexConsumer2 = textureAtlasSprite.wrap(multiBufferSource.getBuffer(Sheets.armorTrimsSheet(armorTrim.pattern().value().decal())));
				model.renderToBuffer(poseStack, vertexConsumer2, i, OverlayTexture.NO_OVERLAY);
			}
			ci.cancel();
		}
	}
}