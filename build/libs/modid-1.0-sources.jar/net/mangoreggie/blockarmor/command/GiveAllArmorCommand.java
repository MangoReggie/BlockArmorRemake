package net.mangoreggie.blockarmor.command;

import net.mangoreggie.blockarmor.procedures.GiveAllArmorCodeProcedure;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2350;
import net.minecraft.class_3218;
import net.minecraft.class_7157;
import net.fabricmc.fabric.api.entity.FakePlayer;

import com.mojang.brigadier.CommandDispatcher;

public class GiveAllArmorCommand {
	public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 commandBuildContext, class_2170.class_5364 environment) {
		dispatcher.register(class_2170.method_9247("giveallarmor").requires(s -> s.method_9259(4)).executes(arguments -> {
			class_1937 world = arguments.getSource().method_9225();
			double x = arguments.getSource().method_9222().method_10216();
			double y = arguments.getSource().method_9222().method_10214();
			double z = arguments.getSource().method_9222().method_10215();
			class_1297 entity = arguments.getSource().method_9228();
			if (entity == null && world instanceof class_3218 _servLevel)
				entity = FakePlayer.get(_servLevel);
			class_2350 direction = class_2350.field_11033;
			if (entity != null)
				direction = entity.method_5735();

			GiveAllArmorCodeProcedure.execute(world, entity);
			return 0;
		}));
	}
}