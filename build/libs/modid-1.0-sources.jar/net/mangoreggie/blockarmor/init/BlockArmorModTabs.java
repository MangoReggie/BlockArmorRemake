/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mangoreggie.blockarmor.init;

import net.mangoreggie.blockarmor.BlockArmorMod;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;

public class BlockArmorModTabs {
	public static class_5321<class_1761> TAB_BLOCK_ARMOR = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(BlockArmorMod.MODID, "block_armor"));

	public static void load() {
		class_2378.method_39197(class_7923.field_44687, TAB_BLOCK_ARMOR,
				FabricItemGroup.builder().method_47321(class_2561.method_43471("item_group.block_armor.block_armor")).method_47320(() -> new class_1799(BlockArmorModItems.DIRT_CHESTPLATE)).method_47317((parameters, tabData) -> {
					tabData.method_45421(BlockArmorModItems.DIRT_HELMET);
					tabData.method_45421(BlockArmorModItems.DIRT_CHESTPLATE);
					tabData.method_45421(BlockArmorModItems.DIRT_LEGGINGS);
					tabData.method_45421(BlockArmorModItems.DIRT_BOOTS);
					tabData.method_45421(BlockArmorModItems.STONE_HELMET);
					tabData.method_45421(BlockArmorModItems.STONE_CHESTPLATE);
					tabData.method_45421(BlockArmorModItems.STONE_LEGGINGS);
					tabData.method_45421(BlockArmorModItems.STONE_BOOTS);
					tabData.method_45421(BlockArmorModItems.GRANITE_HELMET);
					tabData.method_45421(BlockArmorModItems.GRANITE_CHESTPLATE);
					tabData.method_45421(BlockArmorModItems.GRANITE_LEGGINGS);
					tabData.method_45421(BlockArmorModItems.GRANITE_BOOTS);
					tabData.method_45421(BlockArmorModItems.MOSSY_STONE_BRICK_HELMET);
					tabData.method_45421(BlockArmorModItems.MOSSY_STONE_BRICK_CHESTPLATE);
					tabData.method_45421(BlockArmorModItems.MOSSY_STONE_BRICK_LEGGINGS);
					tabData.method_45421(BlockArmorModItems.MOSSY_STONE_BRICK_BOOTS);
					tabData.method_45421(BlockArmorModItems.OBSIDIAN_HELMET);
					tabData.method_45421(BlockArmorModItems.OBSIDIAN_CHESTPLATE);
					tabData.method_45421(BlockArmorModItems.OBSIDIAN_LEGGINGS);
					tabData.method_45421(BlockArmorModItems.OBSIDIAN_BOOTS);
					tabData.method_45421(BlockArmorModItems.AMETHYST_HELMET);
					tabData.method_45421(BlockArmorModItems.AMETHYST_CHESTPLATE);
					tabData.method_45421(BlockArmorModItems.AMETHYST_LEGGINGS);
					tabData.method_45421(BlockArmorModItems.AMETHYST_BOOTS);
					tabData.method_45421(BlockArmorModItems.HONEY_COMB_HELMET);
					tabData.method_45421(BlockArmorModItems.HONEY_COMB_CHESTPLATE);
					tabData.method_45421(BlockArmorModItems.HONEY_COMB_LEGGINGS);
					tabData.method_45421(BlockArmorModItems.HONEY_COMB_BOOTS);
					tabData.method_45421(BlockArmorModItems.TUFF_HELMET);
					tabData.method_45421(BlockArmorModItems.TUFF_CHESTPLATE);
					tabData.method_45421(BlockArmorModItems.TUFF_LEGGINGS);
					tabData.method_45421(BlockArmorModItems.TUFF_BOOTS);
					tabData.method_45421(BlockArmorModItems.GLOWSTONE_HELMET);
					tabData.method_45421(BlockArmorModItems.GLOWSTONE_CHESTPLATE);
					tabData.method_45421(BlockArmorModItems.GLOWSTONE_LEGGINGS);
					tabData.method_45421(BlockArmorModItems.GLOWSTONE_BOOTS);
					tabData.method_45421(BlockArmorModItems.SPONGE_HELMET);
					tabData.method_45421(BlockArmorModItems.SPONGE_CHESTPLATE);
					tabData.method_45421(BlockArmorModItems.SPONGE_LEGGINGS);
					tabData.method_45421(BlockArmorModItems.SPONGE_BOOTS);
					tabData.method_45421(BlockArmorModItems.TUFF_BRICKS_HELMET);
					tabData.method_45421(BlockArmorModItems.TUFF_BRICKS_CHESTPLATE);
					tabData.method_45421(BlockArmorModItems.TUFF_BRICKS_LEGGINGS);
					tabData.method_45421(BlockArmorModItems.TUFF_BRICKS_BOOTS);
					tabData.method_45421(BlockArmorModItems.OAK_PLANK_HELMET);
					tabData.method_45421(BlockArmorModItems.OAK_PLANK_CHESTPLATE);
					tabData.method_45421(BlockArmorModItems.OAK_PLANK_LEGGINGS);
					tabData.method_45421(BlockArmorModItems.OAK_PLANK_BOOTS);
					tabData.method_45421(BlockArmorModItems.CHORUS_FLOWER_HELMET);
					tabData.method_45421(BlockArmorModItems.CHORUS_FLOWER_CHESTPLATE);
					tabData.method_45421(BlockArmorModItems.CHORUS_FLOWER_LEGGINGS);
					tabData.method_45421(BlockArmorModItems.CHORUS_FLOWER_BOOTS);
					tabData.method_45421(BlockArmorModItems.MELON_HELMET);
					tabData.method_45421(BlockArmorModItems.MELON_CHESTPLATE);
					tabData.method_45421(BlockArmorModItems.MELON_LEGGINGS);
					tabData.method_45421(BlockArmorModItems.MELON_BOOTS);
					tabData.method_45421(BlockArmorModItems.RED_SANDSTONE_HELMET);
					tabData.method_45421(BlockArmorModItems.RED_SANDSTONE_CHESTPLATE);
					tabData.method_45421(BlockArmorModItems.RED_SANDSTONE_LEGGINGS);
					tabData.method_45421(BlockArmorModItems.RED_SANDSTONE_BOOTS);
					tabData.method_45421(BlockArmorModItems.BOOKSHELF_HELMET);
					tabData.method_45421(BlockArmorModItems.BOOKSHELF_CHESTPLATE);
					tabData.method_45421(BlockArmorModItems.BOOKSHELF_LEGGINGS);
					tabData.method_45421(BlockArmorModItems.BOOKSHELF_BOOTS);
					tabData.method_45421(BlockArmorModItems.JACK_O_LANTERN_HELMET);
					tabData.method_45421(BlockArmorModItems.JACK_O_LANTERN_CHESTPLATE);
					tabData.method_45421(BlockArmorModItems.JACK_O_LANTERN_LEGGINGS);
					tabData.method_45421(BlockArmorModItems.JACK_O_LANTERN_BOOTS);
					tabData.method_45421(BlockArmorModItems.RED_MUSHROOM_HELMET);
					tabData.method_45421(BlockArmorModItems.RED_MUSHROOM_CHESTPLATE);
					tabData.method_45421(BlockArmorModItems.RED_MUSHROOM_LEGGINGS);
					tabData.method_45421(BlockArmorModItems.RED_MUSHROOM_BOOTS);
					tabData.method_45421(BlockArmorModItems.CALCITE_HELMET);
					tabData.method_45421(BlockArmorModItems.CALCITE_CHESTPLATE);
					tabData.method_45421(BlockArmorModItems.CALCITE_LEGGINGS);
					tabData.method_45421(BlockArmorModItems.CALCITE_BOOTS);
					tabData.method_45421(BlockArmorModItems.BROWN_MUSHROOM_HELMET);
					tabData.method_45421(BlockArmorModItems.BROWN_MUSHROOM_CHESTPLATE);
					tabData.method_45421(BlockArmorModItems.BROWN_MUSHROOM_LEGGINGS);
					tabData.method_45421(BlockArmorModItems.BROWN_MUSHROOM_BOOTS);
				}).method_47324());
	}
}