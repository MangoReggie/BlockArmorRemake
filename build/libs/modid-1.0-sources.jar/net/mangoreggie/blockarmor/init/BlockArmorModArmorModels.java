/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mangoreggie.blockarmor.init;

import net.mangoreggie.blockarmor.client.renderer.item.*;
import net.minecraft.class_10186;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3879;
import net.minecraft.class_572;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import java.util.Map;

import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;

@Environment(EnvType.CLIENT)
public class BlockArmorModArmorModels {
	public static Map<class_1792, ArmorModel> ARMOR_MODELS = new Reference2ObjectOpenHashMap<>();

	public static class ArmorModel {
		public ArmorModel() {
		}

		public class_572 getHumanoidArmorModel(class_1799 itemStack, class_10186.class_10190 layerType, class_3879 original) {
			return null;
		}

		public class_2960 getArmorTexture(class_1799 stack, class_10186.class_10190 type, class_10186.class_10189 layer, class_2960 _default) {
			return null;
		}

		public class_3879 getGenericArmorModel(class_1799 itemStack, class_10186.class_10190 layerType, class_3879 original) {
			class_3879 replacement = getHumanoidArmorModel(itemStack, layerType, original);
			if (replacement != original) {
				if (original instanceof class_572<?> originalHumanoid && replacement instanceof class_572<?> replacementHumanoid) {
					originalHumanoid.method_64254((class_572) replacement);
					replacementHumanoid.field_3398.field_3665 = originalHumanoid.field_3398.field_3665;
					replacementHumanoid.field_3394.field_3665 = originalHumanoid.field_3394.field_3665;
					replacementHumanoid.field_3391.field_3665 = originalHumanoid.field_3391.field_3665;
					replacementHumanoid.field_3401.field_3665 = originalHumanoid.field_3401.field_3665;
					replacementHumanoid.field_27433.field_3665 = originalHumanoid.field_27433.field_3665;
					replacementHumanoid.field_3392.field_3665 = originalHumanoid.field_3392.field_3665;
					replacementHumanoid.field_3397.field_3665 = originalHumanoid.field_3397.field_3665;
				}
				return replacement;
			}
			return original;
		}
	}

	public static void clientLoad() {
		DirtArmorArmor.clientLoad();
		StoneArmor.clientLoad();
		GraniteArmor.clientLoad();
		MossyStoneBrickArmor.clientLoad();
		ObsidianArmor.clientLoad();
		AmethystArmor.clientLoad();
		HoneyCombArmor.clientLoad();
		TuffArmor.clientLoad();
		GlowstoneArmor.clientLoad();
		SpongeArmor.clientLoad();
		TuffBricksArmor.clientLoad();
		OakPlankArmor.clientLoad();
		ChorusFlowerArmor.clientLoad();
		MelonArmor.clientLoad();
		RedSandstoneArmor.clientLoad();
		BookshelfArmor.clientLoad();
		JackOLanternArmor.clientLoad();
		RedMushroomArmor.clientLoad();
		CalciteArmor.clientLoad();
		BrownMushroomArmor.clientLoad();
	}
}