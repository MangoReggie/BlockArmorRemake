package net.mangoreggie.blockarmor.procedures;

import net.mangoreggie.blockarmor.BlockArmorMod;
import net.minecraft.class_1297;
import net.minecraft.class_1936;

public class GiveAllArmorCodeProcedure {
	public static boolean eventResult = true;

	public static void execute(class_1936 world, class_1297 entity) {
		if (entity == null)
			return;
		BlockArmorMod.queueServerWork(400, () -> {
		});
		BlockArmorMod.queueServerWork(800, () -> {
		});
	}
}