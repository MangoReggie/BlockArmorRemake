package net.mangoreggie.blockarmor.procedures;

import net.mangoreggie.blockarmor.network.BlockArmorModVariables;
import net.minecraft.class_1936;

public class UnSinkProcedure {
	public static boolean eventResult = true;

	public static void execute(class_1936 world) {
		BlockArmorModVariables.WorldVariables.get(world).spaceHeld = true;
		BlockArmorModVariables.WorldVariables.get(world).markSyncDirty();
	}
}