package net.mangoreggie.blockarmor.procedures;

import net.mangoreggie.blockarmor.network.BlockArmorModVariables;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.mangoreggie.blockarmor.event.PlayerEvents;

public class XPEffectProcedure {
	public static boolean eventResult = true;

	public XPEffectProcedure() {
		PlayerEvents.END_PLAYER_TICK.register(entity -> {
			execute(entity.method_37908(), entity);
		});
	}

	public static void execute(class_1936 world, class_1297 entity) {
		if (entity == null)
			return;
		class_1799 enchItem = class_1799.field_8037;
		double armorCount = 0;
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6169) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:xp")))) {
			armorCount = armorCount + 1;
		}
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6174) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:xp")))) {
			armorCount = armorCount + 1;
		}
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6172) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:xp")))) {
			armorCount = armorCount + 1;
		}
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6166) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:xp")))) {
			armorCount = armorCount + 1;
		}
		if (BlockArmorModVariables.MapVariables.get(world).BlockArmorTimer == 0 && armorCount >= 2) {
			if (entity instanceof class_1657 _player) {
				_player.method_7255(1);
			}
		}
		armorCount = 0;
	}
}