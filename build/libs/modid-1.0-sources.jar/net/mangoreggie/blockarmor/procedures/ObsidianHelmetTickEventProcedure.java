package net.mangoreggie.blockarmor.procedures;

import net.mangoreggie.blockarmor.event.PlayerEvents;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1893;
import net.minecraft.class_1936;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class ObsidianHelmetTickEventProcedure {
	public static boolean eventResult = true;

	public ObsidianHelmetTickEventProcedure() {
		PlayerEvents.END_PLAYER_TICK.register(entity -> {
			execute(entity.method_37908(), entity);
		});
	}

	public static void execute(class_1936 world, class_1297 entity) {
		if (entity == null)
			return;
		double armorCount = 0;
		class_1799 enchItem = class_1799.field_8037;
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6169) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:obsidian_armor")))) {
			armorCount = armorCount + 1;
		}
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6174) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:obsidian_armor")))) {
			armorCount = armorCount + 1;
		}
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6172) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:obsidian_armor")))) {
			armorCount = armorCount + 1;
		}
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6166) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:obsidian_armor")))) {
			armorCount = armorCount + 1;
		}
		if (armorCount >= 2) {
			if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6169) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:obsidian_armor")))
					&& ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6169) : class_1799.field_8037).method_58657()
							.method_57536(world.method_30349().method_30530(class_7924.field_41265).method_46747(class_1893.field_9095)) != 0) == false) {
				enchItem = (entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6169) : class_1799.field_8037).method_7972();
				enchItem.method_7978(world.method_30349().method_30530(class_7924.field_41265).method_46747(class_1893.field_9095), 4);
				if (entity instanceof class_1309 _living) {
					_living.method_5673(class_1304.field_6169, enchItem);
				}
			}
			if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6174) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:obsidian_armor")))
					&& ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6174) : class_1799.field_8037).method_58657()
							.method_57536(world.method_30349().method_30530(class_7924.field_41265).method_46747(class_1893.field_9095)) != 0) == false) {
				enchItem = (entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6174) : class_1799.field_8037).method_7972();
				enchItem.method_7978(world.method_30349().method_30530(class_7924.field_41265).method_46747(class_1893.field_9095), 4);
				if (entity instanceof class_1309 _living) {
					_living.method_5673(class_1304.field_6174, enchItem);
				}
			}
			if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6172) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:obsidian_armor")))
					&& ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6172) : class_1799.field_8037).method_58657()
							.method_57536(world.method_30349().method_30530(class_7924.field_41265).method_46747(class_1893.field_9095)) != 0) == false) {
				enchItem = (entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6172) : class_1799.field_8037).method_7972();
				enchItem.method_7978(world.method_30349().method_30530(class_7924.field_41265).method_46747(class_1893.field_9095), 4);
				if (entity instanceof class_1309 _living) {
					_living.method_5673(class_1304.field_6172, enchItem);
				}
			}
			if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6166) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:obsidian_armor")))
					&& ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6166) : class_1799.field_8037).method_58657()
							.method_57536(world.method_30349().method_30530(class_7924.field_41265).method_46747(class_1893.field_9095)) != 0) == false) {
				enchItem = (entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6166) : class_1799.field_8037).method_7972();
				enchItem.method_7978(world.method_30349().method_30530(class_7924.field_41265).method_46747(class_1893.field_9095), 4);
				if (entity instanceof class_1309 _living) {
					_living.method_5673(class_1304.field_6166, enchItem);
				}
			}
			if (entity instanceof class_1309 _entity && !_entity.method_37908().method_8608()) {
				_entity.method_6092(new class_1293(class_1294.field_5914, 2, 4, false, false));
			}
		}
		armorCount = 0;
	}
}