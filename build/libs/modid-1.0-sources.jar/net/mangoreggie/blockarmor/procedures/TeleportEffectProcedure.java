package net.mangoreggie.blockarmor.procedures;

import net.mangoreggie.blockarmor.network.BlockArmorModVariables;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3959;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.mangoreggie.blockarmor.event.PlayerEvents;

public class TeleportEffectProcedure {
	public static boolean eventResult = true;

	public TeleportEffectProcedure() {
		PlayerEvents.END_PLAYER_TICK.register(entity -> {
			execute(entity.method_37908(), entity);
		});
	}

	public static void execute(class_1936 world, class_1297 entity) {
		if (entity == null)
			return;
		class_1799 enchItem = class_1799.field_8037;
		double armorCount = 0;
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6169) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:chorus_armor")))) {
			armorCount = armorCount + 1;
		}
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6174) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:chorus_armor")))) {
			armorCount = armorCount + 1;
		}
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6172) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:chorus_armor")))) {
			armorCount = armorCount + 1;
		}
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6166) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:chorus_armor")))) {
			armorCount = armorCount + 1;
		}
		if (armorCount >= 2) {
			if (BlockArmorModVariables.WorldVariables.get(world).cooldown > 0) {
				BlockArmorModVariables.WorldVariables.get(world).cooldown = BlockArmorModVariables.WorldVariables.get(world).cooldown - 1;
				BlockArmorModVariables.WorldVariables.get(world).markSyncDirty();
			}
			if (BlockArmorModVariables.WorldVariables.get(world).cooldown == 0 && BlockArmorModVariables.WorldVariables.get(world).effectKeyHeld == true) {
				{
					class_1297 _ent = entity;
					_ent.method_5859((entity.method_37908().method_17742(new class_3959(entity.method_5836(1f), entity.method_5836(1f).method_1019(entity.method_5828(1f).method_1021(12)), class_3959.class_3960.field_17559, class_3959.class_242.field_1348, entity)).method_17777().method_10263()),
							(entity.method_37908().method_17742(new class_3959(entity.method_5836(1f), entity.method_5836(1f).method_1019(entity.method_5828(1f).method_1021(12)), class_3959.class_3960.field_17559, class_3959.class_242.field_1348, entity)).method_17777().method_10264()),
							(entity.method_37908().method_17742(new class_3959(entity.method_5836(1f), entity.method_5836(1f).method_1019(entity.method_5828(1f).method_1021(12)), class_3959.class_3960.field_17559, class_3959.class_242.field_1348, entity)).method_17777().method_10260()));
					if (_ent instanceof class_3222 _serverPlayer)
						_serverPlayer.field_13987.method_14363(
								(entity.method_37908().method_17742(new class_3959(entity.method_5836(1f), entity.method_5836(1f).method_1019(entity.method_5828(1f).method_1021(12)), class_3959.class_3960.field_17559, class_3959.class_242.field_1348, entity)).method_17777().method_10263()),
								(entity.method_37908().method_17742(new class_3959(entity.method_5836(1f), entity.method_5836(1f).method_1019(entity.method_5828(1f).method_1021(12)), class_3959.class_3960.field_17559, class_3959.class_242.field_1348, entity)).method_17777().method_10264()),
								(entity.method_37908().method_17742(new class_3959(entity.method_5836(1f), entity.method_5836(1f).method_1019(entity.method_5828(1f).method_1021(12)), class_3959.class_3960.field_17559, class_3959.class_242.field_1348, entity)).method_17777().method_10260()),
								_ent.method_36454(), _ent.method_36455());
				}
				BlockArmorModVariables.WorldVariables.get(world).cooldown = 100;
				BlockArmorModVariables.WorldVariables.get(world).markSyncDirty();
			}
		}
		armorCount = 0;
	}
}