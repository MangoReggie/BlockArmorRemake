package net.mangoreggie.blockarmor.procedures;

import net.mangoreggie.blockarmor.network.BlockArmorModVariables;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.mangoreggie.blockarmor.event.PlayerEvents;

public class RegrowthEffectProcedure {
	public static boolean eventResult = true;

	public RegrowthEffectProcedure() {
		PlayerEvents.END_PLAYER_TICK.register(entity -> {
			execute(entity.method_37908(), entity);
		});
	}

	public static void execute(class_1936 world, class_1297 entity) {
		if (entity == null)
			return;
		class_1799 enchItem = class_1799.field_8037;
		double armorCount = 0;
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6169) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:regrow")))) {
			armorCount = armorCount + 1;
		}
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6174) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:regrow")))) {
			armorCount = armorCount + 1;
		}
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6172) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:regrow")))) {
			armorCount = armorCount + 1;
		}
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6166) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:regrow")))) {
			armorCount = armorCount + 1;
		}
		if (armorCount >= 2 && BlockArmorModVariables.MapVariables.get(world).BlockArmorTimer == 0) {
			if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6166) : class_1799.field_8037)
					.method_7919() != (entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6166) : class_1799.field_8037).method_7936()) {
				enchItem = (entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6169) : class_1799.field_8037).method_7972();
				enchItem.method_7974(enchItem.method_7919() - 1);
				if (entity instanceof class_1309 _living) {
					_living.method_5673(class_1304.field_6169, enchItem);
				}
			}
			if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6166) : class_1799.field_8037)
					.method_7919() != (entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6166) : class_1799.field_8037).method_7936()) {
				enchItem = ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6174) : class_1799.field_8037).method_7972()).method_7972();
				enchItem.method_7974(enchItem.method_7919() - 1);
				if (entity instanceof class_1309 _living) {
					_living.method_5673(class_1304.field_6174, enchItem);
				}
			}
			if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6166) : class_1799.field_8037)
					.method_7919() != (entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6166) : class_1799.field_8037).method_7936()) {
				enchItem = ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6172) : class_1799.field_8037).method_7972()).method_7972();
				enchItem.method_7974(enchItem.method_7919() - 1);
				if (entity instanceof class_1309 _living) {
					_living.method_5673(class_1304.field_6172, enchItem);
				}
			}
			if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6166) : class_1799.field_8037)
					.method_7919() != (entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6166) : class_1799.field_8037).method_7936()) {
				enchItem = ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6166) : class_1799.field_8037).method_7972()).method_7972();
				enchItem.method_7974(enchItem.method_7919() - 1);
				if (entity instanceof class_1309 _living) {
					_living.method_5673(class_1304.field_6166, enchItem);
				}
			}
		}
		armorCount = 0;
	}
}