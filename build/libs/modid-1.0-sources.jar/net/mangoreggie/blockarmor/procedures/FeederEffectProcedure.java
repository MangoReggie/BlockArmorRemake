package net.mangoreggie.blockarmor.procedures;

import net.mangoreggie.blockarmor.event.PlayerEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class FeederEffectProcedure {
	public static boolean eventResult = true;

	public FeederEffectProcedure() {
		PlayerEvents.END_PLAYER_TICK.register(entity -> {
			execute(entity);
		});
	}

	public static void execute(class_1297 entity) {
		if (entity == null)
			return;
		class_1799 enchItem = class_1799.field_8037;
		double armorCount = 0;
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6169) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:feeder")))) {
			armorCount = armorCount + 1;
		}
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6174) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:feeder")))) {
			armorCount = armorCount + 1;
		}
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6172) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:feeder")))) {
			armorCount = armorCount + 1;
		}
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6166) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:feeder")))) {
			armorCount = armorCount + 1;
		}
		if (armorCount >= 2 && (entity instanceof class_1657 _plr ? _plr.method_7344().method_7586() : 0) <= 10) {
			if (entity instanceof class_1657 _player) {
				_player.method_7344().method_7580((entity instanceof class_1657 _plr ? _plr.method_7344().method_7586() : 0) + 5);
			}
		}
		armorCount = 0;
	}
}