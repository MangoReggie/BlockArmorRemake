package net.mangoreggie.blockarmor.procedures;

import net.mangoreggie.blockarmor.network.BlockArmorModVariables;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2404;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.mangoreggie.blockarmor.event.PlayerEvents;

public class SinkingEffectProcedure {
	public static boolean eventResult = true;

	public SinkingEffectProcedure() {
		PlayerEvents.END_PLAYER_TICK.register(entity -> {
			execute(entity.method_37908(), entity.method_23317(), entity.method_23318(), entity.method_23321(), entity);
		});
	}

	public static void execute(class_1936 world, double x, double y, double z, class_1297 entity) {
		if (entity == null)
			return;
		class_1799 enchItem = class_1799.field_8037;
		double armorCount = 0;
		double sinkCount = 0;
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6169) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:sinkable")))) {
			sinkCount = sinkCount + 1;
		}
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6174) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:sinkable")))) {
			sinkCount = sinkCount + 1;
		}
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6172) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:sinkable")))) {
			sinkCount = sinkCount + 1;
		}
		if ((entity instanceof class_1309 _entGetArmor ? _entGetArmor.method_6118(class_1304.field_6166) : class_1799.field_8037).method_31573(class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("minecraft:sinkable")))) {
			sinkCount = sinkCount + 1;
		}
		if (sinkCount >= 2) {
			if ((world.method_8320(class_2338.method_49637(x, y, z))).method_26204() instanceof class_2404) {
				entity.method_18799(new class_243(0, (-0.125), 0));
				if (BlockArmorModVariables.WorldVariables.get(world).spaceHeld == true) {
					entity.method_18799(new class_243(0, 0.125, 0));
					if (world instanceof class_3218 _level) {
						_level.method_8503().method_3760().method_43514(class_2561.method_43470("Spacebar is HELD").method_54663(0xff0033).method_27692(class_124.field_1067), false);
					}
				}
			}
		}
		sinkCount = 0;
	}
}