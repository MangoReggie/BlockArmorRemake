package net.mangoreggie.blockarmor.network;

import net.mangoreggie.blockarmor.procedures.UnSinkProcedure;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.mangoreggie.blockarmor.procedures.FlootOnKeyReleasedProcedure;
import net.mangoreggie.blockarmor.BlockArmorMod;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

public record FlootMessage(int eventType, int pressedms) implements class_8710 {
	public static final class_9154<FlootMessage> TYPE = new class_9154<>(class_2960.method_60655(BlockArmorMod.MODID, "key_floot"));
	public static final class_9139<class_9129, FlootMessage> STREAM_CODEC = class_9139.method_56437((class_9129 buffer, FlootMessage message) -> {
		buffer.method_53002(message.eventType);
		buffer.method_53002(message.pressedms);
	}, (class_9129 buffer) -> new FlootMessage(buffer.readInt(), buffer.readInt()));

	@Override
	public class_9154<FlootMessage> method_56479() {
		return TYPE;
	}

	public static void handleData(final FlootMessage message, final ServerPlayNetworking.Context context) {
		context.server().execute(() -> {
			pressAction(context.player(), message.eventType, message.pressedms);
		});
	}

	public static void pressAction(class_1657 entity, int type, int pressedms) {
		class_1937 world = entity.method_37908();
		double x = entity.method_23317();
		double y = entity.method_23318();
		double z = entity.method_23321();
		// security measure to prevent arbitrary chunk generation
		if (!world.method_22340(entity.method_24515()))
			return;
		if (type == 0) {

			UnSinkProcedure.execute(world);
		}
		if (type == 1) {

			FlootOnKeyReleasedProcedure.execute(world);
		}
	}
}