package net.mangoreggie.blockarmor.network;

import net.mangoreggie.blockarmor.BlockArmorMod;
import net.minecraft.class_10741;
import net.minecraft.class_18;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_5425;
import net.minecraft.class_7225;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

public class BlockArmorModVariables {
	public static void variablesLoad() {
		PayloadTypeRegistry.playS2C().register(SavedDataSyncMessage.TYPE, SavedDataSyncMessage.STREAM_CODEC);
		ServerPlayerEvents.JOIN.register((player) -> {
			class_18 mapdata = MapVariables.get(player.method_51469());
			class_18 worlddata = WorldVariables.get(player.method_51469());
			if (mapdata != null)
				ServerPlayNetworking.send(player, new SavedDataSyncMessage(0, mapdata));
			if (worlddata != null)
				ServerPlayNetworking.send(player, new SavedDataSyncMessage(1, worlddata));
		});
		ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((player, origin, destination) -> {
			if (!destination.method_8608()) {
				class_18 worlddata = WorldVariables.get(player.method_51469());
				if (worlddata != null)
					ServerPlayNetworking.send(player, new SavedDataSyncMessage(1, worlddata));
			}
		});
		ServerTickEvents.END_WORLD_TICK.register((level) -> {
			WorldVariables worldVariables = WorldVariables.get(level);
			if (worldVariables._syncDirty) {
				level.method_18456().forEach(player -> ServerPlayNetworking.send(player, new SavedDataSyncMessage(1, worldVariables)));
				worldVariables._syncDirty = false;
			}
			MapVariables mapVariables = MapVariables.get(level);
			if (mapVariables._syncDirty) {
				PlayerLookup.world(level).forEach(player -> ServerPlayNetworking.send(player, new SavedDataSyncMessage(0, mapVariables)));
				mapVariables._syncDirty = false;
			}
		});
	}

	public static class WorldVariables extends class_18 {
		public static final class_10741<WorldVariables> TYPE = new class_10741<>("block_armor_worldvars", ctx -> new WorldVariables(), ctx -> class_2487.field_25128.xmap(tag -> {
			WorldVariables instance = new WorldVariables();
			instance.read(tag, ctx.method_67417().method_30349());
			return instance;
		}, instance -> instance.save(new class_2487(), ctx.method_67417().method_30349())), null);
		boolean _syncDirty = false;
		public boolean spaceHeld = false;
		public boolean effectKeyHeld = false;
		public double cooldown = 100.0;

		public void read(class_2487 nbt, class_7225.class_7874 lookupProvider) {
			spaceHeld = nbt.method_68566("spaceHeld", false);
			effectKeyHeld = nbt.method_68566("effectKeyHeld", false);
			cooldown = nbt.method_68563("cooldown", 0);
		}

		public class_2487 save(class_2487 nbt, class_7225.class_7874 lookupProvider) {
			nbt.method_10556("spaceHeld", spaceHeld);
			nbt.method_10556("effectKeyHeld", effectKeyHeld);
			nbt.method_10549("cooldown", cooldown);
			return nbt;
		}

		public void markSyncDirty() {
			this.method_80();
			this._syncDirty = true;
		}

		static WorldVariables clientSide = new WorldVariables();

		public static WorldVariables get(class_1936 world) {
			if (world instanceof class_3218 level) {
				return level.method_17983().method_17924(WorldVariables.TYPE);
			} else {
				return clientSide;
			}
		}
	}

	public static class MapVariables extends class_18 {
		public static final class_10741<MapVariables> TYPE = new class_10741<>("block_armor_mapvars", ctx -> new MapVariables(), ctx -> class_2487.field_25128.xmap(tag -> {
			MapVariables instance = new MapVariables();
			instance.read(tag, ctx.method_67417().method_30349());
			return instance;
		}, instance -> instance.save(new class_2487(), ctx.method_67417().method_30349())), null);
		boolean _syncDirty = false;
		public double BlockArmorTimer = 0.0;

		public void read(class_2487 nbt, class_7225.class_7874 lookupProvider) {
			BlockArmorTimer = nbt.method_68563("BlockArmorTimer", 0);
		}

		public class_2487 save(class_2487 nbt, class_7225.class_7874 lookupProvider) {
			nbt.method_10549("BlockArmorTimer", BlockArmorTimer);
			return nbt;
		}

		public void markSyncDirty() {
			this.method_80();
			this._syncDirty = true;
		}

		static MapVariables clientSide = new MapVariables();

		public static MapVariables get(class_1936 world) {
			if (world instanceof class_5425 serverLevelAccessor) {
				return serverLevelAccessor.method_8410().method_8503().method_3847(class_1937.field_25179).method_17983().method_17924(MapVariables.TYPE);
			} else {
				return clientSide;
			}
		}
	}

	public record SavedDataSyncMessage(int dataType, class_18 data) implements class_8710 {
		public static final class_9154<SavedDataSyncMessage> TYPE = new class_9154<>(class_2960.method_60655(BlockArmorMod.MODID, "saved_data_sync"));
		public static final class_9139<class_9129, SavedDataSyncMessage> STREAM_CODEC = class_9139.method_56437((class_9129 buffer, SavedDataSyncMessage message) -> {
			buffer.method_53002(message.dataType);
			if (message.data instanceof MapVariables mapVariables)
				buffer.method_10794(mapVariables.save(new class_2487(), buffer.method_56349()));
			else if (message.data instanceof WorldVariables worldVariables)
				buffer.method_10794(worldVariables.save(new class_2487(), buffer.method_56349()));
		}, (class_9129 buffer) -> {
			int dataType = buffer.readInt();
			class_2487 nbt = buffer.method_10798();
			class_18 data = null;
			if (nbt != null) {
				data = dataType == 0 ? new MapVariables() : new WorldVariables();
				if (data instanceof MapVariables mapVariables)
					mapVariables.read(nbt, buffer.method_56349());
				else if (data instanceof WorldVariables worldVariables)
					worldVariables.read(nbt, buffer.method_56349());
			}
			return new SavedDataSyncMessage(dataType, data);
		});

		@Override
		public class_9154<SavedDataSyncMessage> method_56479() {
			return TYPE;
		}

		public static void handleData(final SavedDataSyncMessage message, final ClientPlayNetworking.Context context) {
			if (message.data != null) {
				context.client().execute(() -> {
					if (message.dataType == 0)
						MapVariables.clientSide.read(((MapVariables) message.data).save(new class_2487(), context.player().method_56673()), context.player().method_56673());
					else
						WorldVariables.clientSide.read(((WorldVariables) message.data).save(new class_2487(), context.player().method_56673()), context.player().method_56673());
				});
			}
		}
	}
}