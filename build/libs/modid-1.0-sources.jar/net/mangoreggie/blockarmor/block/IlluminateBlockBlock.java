package net.mangoreggie.blockarmor.block;

import net.mangoreggie.blockarmor.init.BlockArmorModBlocks;
import net.minecraft.class_10225;
import net.minecraft.class_11515;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2498;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_4538;
import net.minecraft.class_4970;
import net.minecraft.class_5819;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

public class IlluminateBlockBlock extends class_2248 implements class_3737 {
	public static final class_2746 WATERLOGGED = class_2741.field_12508;

	public IlluminateBlockBlock(class_4970.class_2251 properties) {
		super(properties.method_9626(class_2498.field_44608).method_9618().method_9631(s -> 15).method_9634().method_22488().method_26247((bs, br, bp) -> true).method_26249((bs, br, bp) -> true).method_26236((bs, br, bp) -> false));
		this.method_9590(this.field_10647.method_11664().method_11657(WATERLOGGED, false));
	}

	@Environment(EnvType.CLIENT)
	public static void registerRenderLayer() {
		BlockRenderLayerMap.putBlock(BlockArmorModBlocks.ILLUMINATE_BLOCK, class_11515.field_60926);
	}

	@Override
	public int method_9505(class_2680 state) {
		return 15;
	}

	@Override
	public class_265 method_26159(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
		return class_259.method_1073();
	}

	@Override
	public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
		return method_9541(1, 1, 0.49, 8, 8, 8);
	}

	@Override
	protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
		super.method_9515(builder);
		builder.method_11667(WATERLOGGED);
	}

	@Override
	public class_2680 method_9605(class_1750 context) {
		boolean flag = context.method_8045().method_8316(context.method_8037()).method_15772() == class_3612.field_15910;
		return super.method_9605(context).method_11657(WATERLOGGED, flag);
	}

	@Override
	public class_3610 method_9545(class_2680 state) {
		return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
	}

	@Override
	public class_2680 method_9559(class_2680 state, class_4538 world, class_10225 scheduledTickAccess, class_2338 currentPos, class_2350 facing, class_2338 facingPos, class_2680 facingState, class_5819 random) {
		if (state.method_11654(WATERLOGGED)) {
			scheduledTickAccess.method_64312(currentPos, class_3612.field_15910, class_3612.field_15910.method_15789(world));
		}
		return super.method_9559(state, world, scheduledTickAccess, currentPos, facing, facingPos, facingState, random);
	}

	@Override
	public class_1799 method_9574(class_4538 world, class_2338 pos, class_2680 state, boolean includeData) {
		return class_1799.field_8037;
	}
}