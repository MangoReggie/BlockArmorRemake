package net.mangoreggie.blockarmor.event;

import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.fabricmc.fabric.api.event.Event;

public class ItemEvents {
	public static final Event<BonemealUsed> BONEMEAL_USED = EventFactory.createArrayBacked(BonemealUsed.class, (callbacks) -> (position, entity, itemstack, blockstate) -> {
		for (BonemealUsed event : callbacks) {
			boolean result = event.onBonemealUsed(position, entity, itemstack, blockstate);
			if (!result) {
				return false;
			}
		}
		return true;
	});

	@FunctionalInterface
	public interface BonemealUsed {
		boolean onBonemealUsed(class_2338 position, class_1297 entity, class_1799 itemstack, class_2680 blockstate);
	}
}