package net.mangoreggie.blockarmor.event;

import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.fabricmc.fabric.api.event.Event;

import java.util.Arrays;

public class LivingEntityEvents {
	public static final Event<StartUseItem> START_USE_ITEM = EventFactory.createArrayBacked(StartUseItem.class, (callbacks) -> (entity, itemstack) -> Arrays.stream(callbacks).forEach(callback -> callback.onStartUseItem(entity, itemstack)));
	public static final Event<EntityHeal> ENTITY_HEAL = EventFactory.createArrayBacked(EntityHeal.class, (callbacks) -> (entity, amount) -> {
		for (EntityHeal event : callbacks) {
			boolean result = event.onEntityHeal(entity, amount);
			if (!result) {
				return false;
			}
		}
		return true;
	});

	public static final Event<EntityBlock> ENTITY_BLOCK = EventFactory.createArrayBacked(EntityBlock.class, (callbacks) -> (entity, damagesource, amount) -> {
		for (EntityBlock event : callbacks) {
			boolean result = event.onEntityBlock(entity, damagesource, amount);
			if (!result) {
				return false;
			}
		}
		return true;
	});
	public static final Event<EntityDropXp> ENTITY_DROP_XP = EventFactory.createArrayBacked(EntityDropXp.class, (callbacks) -> (entity, sourceentity, amount) -> {
		for (EntityDropXp event : callbacks) {
			boolean result = event.onEntityDropXp(entity, sourceentity, amount);
			if (!result) {
				return false;
			}
		}
		return true;
	});
	public static final Event<EntityFall> ENTITY_FALL = EventFactory.createArrayBacked(EntityFall.class, (callbacks) -> (entity, falldistance, damagemultiplier) -> {
		for (EntityFall event : callbacks) {
			boolean result = event.onEntityFall(entity, falldistance, damagemultiplier);
			if (!result) {
				return false;
			}
		}
		return true;
	});
	public static final Event<EntityPickupItem> ENTITY_PICKUP_ITEM = EventFactory.createArrayBacked(EntityPickupItem.class,
			(callbacks) -> (entity, itemstack) -> Arrays.stream(callbacks).forEach(callback -> callback.onEntityPickupItem(entity, itemstack)));
	public static final Event<EntityJump> ENTITY_JUMP = EventFactory.createArrayBacked(EntityJump.class, (callbacks) -> (entity) -> Arrays.stream(callbacks).forEach(callback -> callback.onEntityJump(entity)));

	@FunctionalInterface
	public interface StartUseItem {
		void onStartUseItem(class_1297 entity, class_1799 itemstack);
	}

	@FunctionalInterface
	public interface EntityHeal {
		boolean onEntityHeal(class_1297 entity, float amount);
	}

	@FunctionalInterface
	public interface EntityBlock {
		boolean onEntityBlock(class_1297 entity, class_1282 damagesource, double amount);
	}

	@FunctionalInterface
	public interface EntityDropXp {
		boolean onEntityDropXp(class_1297 entity, class_1297 sourceentity, double amount);
	}

	@FunctionalInterface
	public interface EntityFall {
		boolean onEntityFall(class_1297 entity, double falldistance, double damagemultiplier);
	}

	@FunctionalInterface
	public interface EntityPickupItem {
		void onEntityPickupItem(class_1297 entity, class_1799 itemstack);
	}

	@FunctionalInterface
	public interface EntityJump {
		void onEntityJump(class_1297 entity);
	}

}