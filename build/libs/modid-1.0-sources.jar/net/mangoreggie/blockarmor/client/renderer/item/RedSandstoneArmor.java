package net.mangoreggie.blockarmor.client.renderer.item;

import net.mangoreggie.blockarmor.init.BlockArmorModItems;
import net.minecraft.class_10186;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.mangoreggie.blockarmor.init.BlockArmorModArmorModels;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

@Environment(EnvType.CLIENT)
public class RedSandstoneArmor {
	public static void clientLoad() {
		BlockArmorModArmorModels.ARMOR_MODELS.put(BlockArmorModItems.RED_SANDSTONE_HELMET, new BlockArmorModArmorModels.ArmorModel() {
			@Override
			public class_2960 getArmorTexture(class_1799 stack, class_10186.class_10190 type, class_10186.class_10189 layer, class_2960 _default) {
				return class_2960.method_60654("block_armor:textures/models/armor/red_sandstone_top_layer_1.png");
			}
		});
		BlockArmorModArmorModels.ARMOR_MODELS.put(BlockArmorModItems.RED_SANDSTONE_CHESTPLATE, new BlockArmorModArmorModels.ArmorModel() {
			@Override
			public class_2960 getArmorTexture(class_1799 stack, class_10186.class_10190 type, class_10186.class_10189 layer, class_2960 _default) {
				return class_2960.method_60654("block_armor:textures/models/armor/red_sandstone_top_layer_1.png");
			}
		});
		BlockArmorModArmorModels.ARMOR_MODELS.put(BlockArmorModItems.RED_SANDSTONE_LEGGINGS, new BlockArmorModArmorModels.ArmorModel() {
			@Override
			public class_2960 getArmorTexture(class_1799 stack, class_10186.class_10190 type, class_10186.class_10189 layer, class_2960 _default) {
				return class_2960.method_60654("block_armor:textures/models/armor/red_sandstone_top_layer_2.png");
			}
		});
		BlockArmorModArmorModels.ARMOR_MODELS.put(BlockArmorModItems.RED_SANDSTONE_BOOTS, new BlockArmorModArmorModels.ArmorModel() {
			@Override
			public class_2960 getArmorTexture(class_1799 stack, class_10186.class_10190 type, class_10186.class_10189 layer, class_2960 _default) {
				return class_2960.method_60654("block_armor:textures/models/armor/red_sandstone_top_layer_1.png");
			}
		});
	}
}