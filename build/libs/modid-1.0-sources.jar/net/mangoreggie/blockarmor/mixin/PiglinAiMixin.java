package net.mangoreggie.blockarmor.mixin;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_4838;
import net.minecraft.class_9274;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_4838.class)
public abstract class PiglinAiMixin {
	@Inject(method = "isWearingSafeArmor(Lnet/minecraft/world/entity/LivingEntity;)Z", at = @At("HEAD"), cancellable = true)
	public static void isWearingSafeArmor(class_1309 entity, CallbackInfoReturnable<Boolean> cir) {
		for (class_1304 equipmentslot : class_9274.field_49224) {
		}
	}
}