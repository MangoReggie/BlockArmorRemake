package net.mangoreggie.blockarmor.mixin;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;
import net.mangoreggie.blockarmor.event.BlockEvents;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_2680;

@Mixin(class_1799.class)
public abstract class ItemStackMixin {
	@Inject(method = "useOn(Lnet/minecraft/world/item/context/UseOnContext;)Lnet/minecraft/world/InteractionResult;", at = @At("TAIL"), cancellable = true)
	public void useOn(class_1838 context, CallbackInfoReturnable<class_1269> cir) {
		class_1657 player = context.method_8036();
		class_1799 copy = context.method_8041().method_7972();
		class_2680 placedAgainst = player.method_37908().method_8320(context.method_8037().method_10093(context.method_8038()));
		if (!player.method_37908().method_22347(context.method_8037().method_10093(context.method_8038()))) {
			boolean result = BlockEvents.BLOCK_MULTIPLACE.invoker().onMultiplaced(context.method_8037().method_10093(context.method_8038()), (class_1297) player, placedAgainst, player.method_37908().method_8320(context.method_8037()));
			if (!result)
				cir.setReturnValue(class_1269.field_5814);
		}
	}
}