package net.mangoreggie.blockarmor.mixin;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Final;
import net.mangoreggie.blockarmor.init.BlockArmorModArmorModels;
import net.minecraft.class_10186;
import net.minecraft.class_10197;
import net.minecraft.class_10201;
import net.minecraft.class_10394;
import net.minecraft.class_1058;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3879;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_4722;
import net.minecraft.class_5321;
import net.minecraft.class_8053;
import net.minecraft.class_918;
import net.minecraft.class_9282;
import net.minecraft.class_9334;
import java.util.function.Function;
import java.util.List;

@Mixin(class_10197.class)
public abstract class EquipmentLayerRendererMixin {
	@Shadow
	@Final
	private class_10201 equipmentAssets;
	@Shadow
	@Final
	private Function<class_10197.class_10198, class_2960> layerTextureLookup;
	@Shadow
	@Final
	private Function<class_10197.class_10199, class_1058> trimSpriteLookup;

	@Shadow
	private static int getColorForLayer(class_10186.class_10189 layer, int i) {
		return 0;
	}

	@Inject(method = "Lnet/minecraft/client/renderer/entity/layers/EquipmentLayerRenderer;renderLayers(Lnet/minecraft/client/resources/model/EquipmentClientInfo$LayerType;Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/client/model/Model;Lnet/minecraft/world/item/ItemStack;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/resources/ResourceLocation;)V", at = @At("HEAD"), cancellable = true)
	public void renderLayers(class_10186.class_10190 layerType, class_5321<class_10394> resourceKey, class_3879 model, class_1799 itemStack, class_4587 poseStack, class_4597 multiBufferSource, int i, class_2960 resourceLocation,
			CallbackInfo ci) {
		if (BlockArmorModArmorModels.ARMOR_MODELS.containsKey(itemStack.method_7909())) {
			BlockArmorModArmorModels.ArmorModel armorModel = BlockArmorModArmorModels.ARMOR_MODELS.get(itemStack.method_7909());
			if (armorModel.getHumanoidArmorModel(itemStack, layerType, model) != null)
				model = armorModel.getGenericArmorModel(itemStack, layerType, model);
			List<class_10186.class_10189> list = this.equipmentAssets.method_64087(resourceKey).method_63996(layerType);
			if (list.isEmpty()) {
				ci.cancel();
			}
			int j = class_9282.method_57470(itemStack, 0);
			boolean bl = itemStack.method_7958();
			for (class_10186.class_10189 layer : list) {
				int k = getColorForLayer(layer, j);
				if (k == 0)
					continue;
				class_2960 resourceLocation2 = layer.comp_3173() && resourceLocation != null ? resourceLocation : this.layerTextureLookup.apply(new class_10197.class_10198(layerType, layer));
				resourceLocation2 = armorModel.getArmorTexture(itemStack, layerType, layer, resourceLocation2);
				class_4588 vertexConsumer = class_918.method_27952(multiBufferSource, class_1921.method_25448(resourceLocation2), bl);
				model.method_62100(poseStack, vertexConsumer, i, class_4608.field_21444, k);
				bl = false;
			}
			class_8053 armorTrim = itemStack.method_58694(class_9334.field_49607);
			if (armorTrim != null) {
				class_1058 textureAtlasSprite = this.trimSpriteLookup.apply(new class_10197.class_10199(armorTrim, layerType, resourceKey));
				class_4588 vertexConsumer2 = textureAtlasSprite.method_24108(multiBufferSource.getBuffer(class_4722.method_48480(armorTrim.comp_3180().comp_349().comp_1905())));
				model.method_60879(poseStack, vertexConsumer2, i, class_4608.field_21444);
			}
			ci.cancel();
		}
	}
}