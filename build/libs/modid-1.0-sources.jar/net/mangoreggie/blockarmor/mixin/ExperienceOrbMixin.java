package net.mangoreggie.blockarmor.mixin;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;
import net.mangoreggie.blockarmor.event.PlayerEvents;
import net.minecraft.class_1303;
import net.minecraft.class_1657;
import net.minecraft.class_3222;

@Mixin(class_1303.class)
public abstract class ExperienceOrbMixin {
	@Inject(method = "playerTouch(Lnet/minecraft/world/entity/player/Player;)V", at = @At("HEAD"), cancellable = true)
	public void playerTouch(class_1657 player, CallbackInfo ci) {
		if (player instanceof class_3222 serverPlayer)
			if (serverPlayer.field_7504 == 0)
				if (!PlayerEvents.PICKUP_XP.invoker().onPickupXp(serverPlayer))
					ci.cancel();
	}
}