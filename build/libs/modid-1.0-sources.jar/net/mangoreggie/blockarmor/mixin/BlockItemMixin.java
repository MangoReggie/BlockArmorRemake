package net.mangoreggie.blockarmor.mixin;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;
import net.mangoreggie.blockarmor.event.BlockEvents;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1838;

@Mixin(class_1747.class)
public abstract class BlockItemMixin {
	@Inject(method = "useOn(Lnet/minecraft/world/item/context/UseOnContext;)Lnet/minecraft/world/InteractionResult;", at = @At("HEAD"), cancellable = true)
	public void useOn(class_1838 context, CallbackInfoReturnable<class_1269> cir) {
		class_1750 placeContext = new class_1750(context);
		boolean result = BlockEvents.BLOCK_PLACE.invoker().onBlockPlaced(context.method_8037(), (class_1297) placeContext.method_8036(), ((class_1747) placeContext.method_8041().method_7909()).method_7711().method_9564(),
				placeContext.method_8036().method_37908().method_8320(context.method_8037()));
		if (!result)
			cir.setReturnValue(class_1269.field_5814);
	}
}