package net.mangoreggie.blockarmor.item;

import java.util.Map;
import net.minecraft.class_10191;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8051;

public abstract class HoneyCombItem extends class_1792 {
	public static class_1741 ARMOR_MATERIAL = new class_1741(30, Map.of(class_8051.field_41937, 2, class_8051.field_41936, 6, class_8051.field_41935, 7, class_8051.field_41934, 2, class_8051.field_48838, 7), 12,
			class_7923.field_41172.method_47983(class_7923.field_41172.method_63535(class_2960.method_60654("item.armor.equip_generic"))), 1f, 0.005f,
			class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("block_armor:honey_comb_repair_items")), class_5321.method_29179(class_10191.field_55214, class_2960.method_60654("block_armor:honey_comb")));

	private HoneyCombItem(class_1792.class_1793 properties) {
		super(properties);
	}

	public static class Helmet extends HoneyCombItem {
		public Helmet(class_1792.class_1793 properties) {
			super(properties.method_66332(ARMOR_MATERIAL, class_8051.field_41934));
		}
	}

	public static class Chestplate extends HoneyCombItem {
		public Chestplate(class_1792.class_1793 properties) {
			super(properties.method_66332(ARMOR_MATERIAL, class_8051.field_41935));
		}
	}

	public static class Leggings extends HoneyCombItem {
		public Leggings(class_1792.class_1793 properties) {
			super(properties.method_66332(ARMOR_MATERIAL, class_8051.field_41936));
		}
	}

	public static class Boots extends HoneyCombItem {
		public Boots(class_1792.class_1793 properties) {
			super(properties.method_66332(ARMOR_MATERIAL, class_8051.field_41937));
		}
	}
}