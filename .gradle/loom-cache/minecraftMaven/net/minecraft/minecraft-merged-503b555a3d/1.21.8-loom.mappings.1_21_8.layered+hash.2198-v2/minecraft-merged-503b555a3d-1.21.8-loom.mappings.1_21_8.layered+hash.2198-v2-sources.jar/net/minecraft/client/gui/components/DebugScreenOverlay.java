/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.client.gui.components;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.platform.GLX;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.datafixers.DataFixUtils;
import it.unimi.dsi.fastutil.longs.LongSets;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.ChatFormatting;
import net.minecraft.SharedConstants;
import net.minecraft.Util;
import net.minecraft.client.Camera;
import net.minecraft.client.ClientBrandRetriever;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.debugchart.BandwidthDebugChart;
import net.minecraft.client.gui.components.debugchart.FpsDebugChart;
import net.minecraft.client.gui.components.debugchart.PingDebugChart;
import net.minecraft.client.gui.components.debugchart.ProfilerPieChart;
import net.minecraft.client.gui.components.debugchart.TpsDebugChart;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.renderer.DynamicUniforms;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.core.SectionPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.Connection;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.ServerTickRateManager;
import net.minecraft.server.level.ServerChunkCache;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.util.debugchart.LocalSampleLogger;
import net.minecraft.util.debugchart.RemoteDebugSampleType;
import net.minecraft.util.debugchart.TpsDebugDimensions;
import net.minecraft.util.profiling.Profiler;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.util.profiling.Zone;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.TickRateManager;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.NaturalSpawner;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.biome.Climate;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;
import org.joml.Vector3f;
import org.joml.Vector4f;

@Environment(value=EnvType.CLIENT)
public class DebugScreenOverlay {
    private static final float CROSSHAIR_SCALE = 0.01f;
    private static final int CROSHAIR_INDEX_COUNT = 18;
    private static final int COLOR_GREY = -2039584;
    private static final int MARGIN_RIGHT = 2;
    private static final int MARGIN_LEFT = 2;
    private static final int MARGIN_TOP = 2;
    private static final Map<Heightmap.Types, String> HEIGHTMAP_NAMES = Maps.newEnumMap(Map.of(Heightmap.Types.WORLD_SURFACE_WG, "SW", Heightmap.Types.WORLD_SURFACE, "S", Heightmap.Types.OCEAN_FLOOR_WG, "OW", Heightmap.Types.OCEAN_FLOOR, "O", Heightmap.Types.MOTION_BLOCKING, "M", Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, "ML"));
    private final Minecraft minecraft;
    private final AllocationRateCalculator allocationRateCalculator;
    private final Font font;
    private final GpuBuffer crosshairBuffer;
    private final RenderSystem.AutoStorageIndexBuffer crosshairIndicies = RenderSystem.getSequentialBuffer(VertexFormat.Mode.LINES);
    private HitResult block;
    private HitResult liquid;
    @Nullable
    private ChunkPos lastPos;
    @Nullable
    private LevelChunk clientChunk;
    @Nullable
    private CompletableFuture<LevelChunk> serverChunk;
    private boolean renderDebug;
    private boolean renderProfilerChart;
    private boolean renderFpsCharts;
    private boolean renderNetworkCharts;
    private final LocalSampleLogger frameTimeLogger = new LocalSampleLogger(1);
    private final LocalSampleLogger tickTimeLogger = new LocalSampleLogger(TpsDebugDimensions.values().length);
    private final LocalSampleLogger pingLogger = new LocalSampleLogger(1);
    private final LocalSampleLogger bandwidthLogger = new LocalSampleLogger(1);
    private final Map<RemoteDebugSampleType, LocalSampleLogger> remoteSupportingLoggers = Map.of(RemoteDebugSampleType.TICK_TIME, this.tickTimeLogger);
    private final FpsDebugChart fpsChart;
    private final TpsDebugChart tpsChart;
    private final PingDebugChart pingChart;
    private final BandwidthDebugChart bandwidthChart;
    private final ProfilerPieChart profilerPieChart;

    public DebugScreenOverlay(Minecraft minecraft) {
        this.minecraft = minecraft;
        this.allocationRateCalculator = new AllocationRateCalculator();
        this.font = minecraft.font;
        this.fpsChart = new FpsDebugChart(this.font, this.frameTimeLogger);
        this.tpsChart = new TpsDebugChart(this.font, this.tickTimeLogger, () -> Float.valueOf(minecraft.level.tickRateManager().millisecondsPerTick()));
        this.pingChart = new PingDebugChart(this.font, this.pingLogger);
        this.bandwidthChart = new BandwidthDebugChart(this.font, this.bandwidthLogger);
        this.profilerPieChart = new ProfilerPieChart(this.font);
        try (ByteBufferBuilder byteBufferBuilder = ByteBufferBuilder.exactlySized(DefaultVertexFormat.POSITION_COLOR_NORMAL.getVertexSize() * 12);){
            BufferBuilder bufferBuilder = new BufferBuilder(byteBufferBuilder, VertexFormat.Mode.LINES, DefaultVertexFormat.POSITION_COLOR_NORMAL);
            bufferBuilder.addVertex(0.0f, 0.0f, 0.0f).setColor(-65536).setNormal(1.0f, 0.0f, 0.0f);
            bufferBuilder.addVertex(1.0f, 0.0f, 0.0f).setColor(-65536).setNormal(1.0f, 0.0f, 0.0f);
            bufferBuilder.addVertex(0.0f, 0.0f, 0.0f).setColor(-16711936).setNormal(0.0f, 1.0f, 0.0f);
            bufferBuilder.addVertex(0.0f, 1.0f, 0.0f).setColor(-16711936).setNormal(0.0f, 1.0f, 0.0f);
            bufferBuilder.addVertex(0.0f, 0.0f, 0.0f).setColor(-8421377).setNormal(0.0f, 0.0f, 1.0f);
            bufferBuilder.addVertex(0.0f, 0.0f, 1.0f).setColor(-8421377).setNormal(0.0f, 0.0f, 1.0f);
            try (MeshData meshData = bufferBuilder.buildOrThrow();){
                this.crosshairBuffer = RenderSystem.getDevice().createBuffer(() -> "Crosshair vertex buffer", 32, meshData.vertexBuffer());
            }
        }
    }

    public void clearChunkCache() {
        this.serverChunk = null;
        this.clientChunk = null;
    }

    public void render(GuiGraphics guiGraphics) {
        int k;
        int j;
        int i;
        ProfilerFiller profilerFiller = Profiler.get();
        profilerFiller.push("debug");
        Entity entity = this.minecraft.getCameraEntity();
        this.block = entity.pick(20.0, 0.0f, false);
        this.liquid = entity.pick(20.0, 0.0f, true);
        this.drawGameInformation(guiGraphics);
        this.drawSystemInformation(guiGraphics);
        guiGraphics.nextStratum();
        this.profilerPieChart.setBottomOffset(10);
        if (this.renderFpsCharts) {
            i = guiGraphics.guiWidth();
            j = i / 2;
            this.fpsChart.drawChart(guiGraphics, 0, this.fpsChart.getWidth(j));
            if (this.tickTimeLogger.size() > 0) {
                k = this.tpsChart.getWidth(j);
                this.tpsChart.drawChart(guiGraphics, i - k, k);
            }
            this.profilerPieChart.setBottomOffset(this.tpsChart.getFullHeight());
        }
        if (this.renderNetworkCharts) {
            i = guiGraphics.guiWidth();
            j = i / 2;
            if (!this.minecraft.isLocalServer()) {
                this.bandwidthChart.drawChart(guiGraphics, 0, this.bandwidthChart.getWidth(j));
            }
            k = this.pingChart.getWidth(j);
            this.pingChart.drawChart(guiGraphics, i - k, k);
            this.profilerPieChart.setBottomOffset(this.pingChart.getFullHeight());
        }
        try (Zone zone = profilerFiller.zone("profilerPie");){
            this.profilerPieChart.render(guiGraphics);
        }
        profilerFiller.pop();
    }

    protected void drawGameInformation(GuiGraphics guiGraphics) {
        List<String> list = this.getGameInformation();
        list.add("");
        boolean bl = this.minecraft.getSingleplayerServer() != null;
        list.add("Debug charts: [F3+1] Profiler " + (this.renderProfilerChart ? "visible" : "hidden") + "; [F3+2] " + (bl ? "FPS + TPS " : "FPS ") + (this.renderFpsCharts ? "visible" : "hidden") + "; [F3+3] " + (!this.minecraft.isLocalServer() ? "Bandwidth + Ping" : "Ping") + (this.renderNetworkCharts ? " visible" : " hidden"));
        list.add("For help: press F3 + Q");
        this.renderLines(guiGraphics, list, true);
    }

    protected void drawSystemInformation(GuiGraphics guiGraphics) {
        List<String> list = this.getSystemInformation();
        this.renderLines(guiGraphics, list, false);
    }

    private void renderLines(GuiGraphics guiGraphics, List<String> list, boolean bl) {
        int m;
        int l;
        int k;
        String string;
        int j;
        int i = this.font.lineHeight;
        for (j = 0; j < list.size(); ++j) {
            string = list.get(j);
            if (Strings.isNullOrEmpty(string)) continue;
            k = this.font.width(string);
            l = bl ? 2 : guiGraphics.guiWidth() - 2 - k;
            m = 2 + i * j;
            guiGraphics.fill(l - 1, m - 1, l + k + 1, m + i - 1, -1873784752);
        }
        for (j = 0; j < list.size(); ++j) {
            string = list.get(j);
            if (Strings.isNullOrEmpty(string)) continue;
            k = this.font.width(string);
            l = bl ? 2 : guiGraphics.guiWidth() - 2 - k;
            m = 2 + i * j;
            guiGraphics.drawString(this.font, string, l, m, -2039584, false);
        }
    }

    protected List<String> getGameInformation() {
        ResourceLocation resourceLocation;
        Level level;
        String string3;
        IntegratedServer integratedServer = this.minecraft.getSingleplayerServer();
        ClientPacketListener clientPacketListener = this.minecraft.getConnection();
        Connection connection = clientPacketListener.getConnection();
        float f = connection.getAverageSentPackets();
        float g = connection.getAverageReceivedPackets();
        TickRateManager tickRateManager = this.getLevel().tickRateManager();
        String string = tickRateManager.isSteppingForward() ? " (frozen - stepping)" : (tickRateManager.isFrozen() ? " (frozen)" : "");
        if (integratedServer != null) {
            ServerTickRateManager serverTickRateManager = integratedServer.tickRateManager();
            boolean bl = serverTickRateManager.isSprinting();
            if (bl) {
                string = " (sprinting)";
            }
            String string2 = bl ? "-" : String.format(Locale.ROOT, "%.1f", Float.valueOf(tickRateManager.millisecondsPerTick()));
            string3 = String.format(Locale.ROOT, "Integrated server @ %.1f/%s ms%s, %.0f tx, %.0f rx", Float.valueOf(integratedServer.getCurrentSmoothedTickTime()), string2, string, Float.valueOf(f), Float.valueOf(g));
        } else {
            string3 = String.format(Locale.ROOT, "\"%s\" server%s, %.0f tx, %.0f rx", clientPacketListener.serverBrand(), string, Float.valueOf(f), Float.valueOf(g));
        }
        BlockPos blockPos = this.minecraft.getCameraEntity().blockPosition();
        if (this.minecraft.showOnlyReducedInfo()) {
            return Lists.newArrayList("Minecraft " + SharedConstants.getCurrentVersion().name() + " (" + this.minecraft.getLaunchedVersion() + "/" + ClientBrandRetriever.getClientModName() + ")", this.minecraft.fpsString, string3, this.minecraft.levelRenderer.getSectionStatistics(), this.minecraft.levelRenderer.getEntityStatistics(), "P: " + this.minecraft.particleEngine.countParticles() + ". T: " + this.minecraft.level.getEntityCount(), this.minecraft.level.gatherChunkSourceStats(), "", String.format(Locale.ROOT, "Chunk-relative: %d %d %d", blockPos.getX() & 0xF, blockPos.getY() & 0xF, blockPos.getZ() & 0xF));
        }
        Entity entity = this.minecraft.getCameraEntity();
        Direction direction = entity.getDirection();
        String string4 = switch (direction) {
            case Direction.NORTH -> "Towards negative Z";
            case Direction.SOUTH -> "Towards positive Z";
            case Direction.WEST -> "Towards negative X";
            case Direction.EAST -> "Towards positive X";
            default -> "Invalid";
        };
        ChunkPos chunkPos = new ChunkPos(blockPos);
        if (!Objects.equals(this.lastPos, chunkPos)) {
            this.lastPos = chunkPos;
            this.clearChunkCache();
        }
        LongSets.EmptySet longSet = (level = this.getLevel()) instanceof ServerLevel ? ((ServerLevel)level).getForceLoadedChunks() : LongSets.EMPTY_SET;
        ArrayList<String> list = Lists.newArrayList("Minecraft " + SharedConstants.getCurrentVersion().name() + " (" + this.minecraft.getLaunchedVersion() + "/" + ClientBrandRetriever.getClientModName() + (String)("release".equalsIgnoreCase(this.minecraft.getVersionType()) ? "" : "/" + this.minecraft.getVersionType()) + ")", this.minecraft.fpsString, string3, this.minecraft.levelRenderer.getSectionStatistics(), this.minecraft.levelRenderer.getEntityStatistics(), "P: " + this.minecraft.particleEngine.countParticles() + ". T: " + this.minecraft.level.getEntityCount(), this.minecraft.level.gatherChunkSourceStats());
        String string5 = this.getServerChunkStats();
        if (string5 != null) {
            list.add(string5);
        }
        list.add(String.valueOf(this.minecraft.level.dimension().location()) + " FC: " + longSet.size());
        list.add("");
        list.add(String.format(Locale.ROOT, "XYZ: %.3f / %.5f / %.3f", this.minecraft.getCameraEntity().getX(), this.minecraft.getCameraEntity().getY(), this.minecraft.getCameraEntity().getZ()));
        list.add(String.format(Locale.ROOT, "Block: %d %d %d [%d %d %d]", blockPos.getX(), blockPos.getY(), blockPos.getZ(), blockPos.getX() & 0xF, blockPos.getY() & 0xF, blockPos.getZ() & 0xF));
        list.add(String.format(Locale.ROOT, "Chunk: %d %d %d [%d %d in r.%d.%d.mca]", chunkPos.x, SectionPos.blockToSectionCoord(blockPos.getY()), chunkPos.z, chunkPos.getRegionLocalX(), chunkPos.getRegionLocalZ(), chunkPos.getRegionX(), chunkPos.getRegionZ()));
        list.add(String.format(Locale.ROOT, "Facing: %s (%s) (%.1f / %.1f)", direction, string4, Float.valueOf(Mth.wrapDegrees(entity.getYRot())), Float.valueOf(Mth.wrapDegrees(entity.getXRot()))));
        LevelChunk levelChunk = this.getClientChunk();
        if (levelChunk.isEmpty()) {
            list.add("Waiting for chunk...");
        } else {
            int i = this.minecraft.level.getChunkSource().getLightEngine().getRawBrightness(blockPos, 0);
            int j = this.minecraft.level.getBrightness(LightLayer.SKY, blockPos);
            int k = this.minecraft.level.getBrightness(LightLayer.BLOCK, blockPos);
            list.add("Client Light: " + i + " (" + j + " sky, " + k + " block)");
            LevelChunk levelChunk2 = this.getServerChunk();
            StringBuilder stringBuilder = new StringBuilder("CH");
            for (Heightmap.Types types : Heightmap.Types.values()) {
                if (!types.sendToClient()) continue;
                stringBuilder.append(" ").append(HEIGHTMAP_NAMES.get(types)).append(": ").append(levelChunk.getHeight(types, blockPos.getX(), blockPos.getZ()));
            }
            list.add(stringBuilder.toString());
            stringBuilder.setLength(0);
            stringBuilder.append("SH");
            for (Heightmap.Types types : Heightmap.Types.values()) {
                if (!types.keepAfterWorldgen()) continue;
                stringBuilder.append(" ").append(HEIGHTMAP_NAMES.get(types)).append(": ");
                if (levelChunk2 != null) {
                    stringBuilder.append(levelChunk2.getHeight(types, blockPos.getX(), blockPos.getZ()));
                    continue;
                }
                stringBuilder.append("??");
            }
            list.add(stringBuilder.toString());
            if (this.minecraft.level.isInsideBuildHeight(blockPos.getY())) {
                list.add("Biome: " + DebugScreenOverlay.printBiome(this.minecraft.level.getBiome(blockPos)));
                if (levelChunk2 != null) {
                    float h = level.getMoonBrightness();
                    long l = levelChunk2.getInhabitedTime();
                    DifficultyInstance difficultyInstance = new DifficultyInstance(level.getDifficulty(), level.getDayTime(), l, h);
                    list.add(String.format(Locale.ROOT, "Local Difficulty: %.2f // %.2f (Day %d)", Float.valueOf(difficultyInstance.getEffectiveDifficulty()), Float.valueOf(difficultyInstance.getSpecialMultiplier()), this.minecraft.level.getDayTime() / 24000L));
                } else {
                    list.add("Local Difficulty: ??");
                }
            }
            if (levelChunk2 != null && levelChunk2.isOldNoiseGeneration()) {
                list.add("Blending: Old");
            }
        }
        ServerLevel serverLevel = this.getServerLevel();
        if (serverLevel != null) {
            ServerChunkCache serverChunkCache = serverLevel.getChunkSource();
            ChunkGenerator chunkGenerator = serverChunkCache.getGenerator();
            RandomState randomState = serverChunkCache.randomState();
            chunkGenerator.addDebugScreenInfo(list, randomState, blockPos);
            Climate.Sampler sampler = randomState.sampler();
            BiomeSource biomeSource = chunkGenerator.getBiomeSource();
            biomeSource.addDebugInfo(list, blockPos, sampler);
            NaturalSpawner.SpawnState spawnState = serverChunkCache.getLastSpawnState();
            if (spawnState != null) {
                Object2IntMap<MobCategory> object2IntMap = spawnState.getMobCategoryCounts();
                int m = spawnState.getSpawnableChunkCount();
                list.add("SC: " + m + ", " + Stream.of(MobCategory.values()).map(mobCategory -> Character.toUpperCase(mobCategory.getName().charAt(0)) + ": " + object2IntMap.getInt(mobCategory)).collect(Collectors.joining(", ")));
            } else {
                list.add("SC: N/A");
            }
        }
        if ((resourceLocation = this.minecraft.gameRenderer.currentPostEffect()) != null) {
            list.add("Post: " + String.valueOf(resourceLocation));
        }
        list.add(this.minecraft.getSoundManager().getDebugString() + String.format(Locale.ROOT, " (Mood %d%%)", Math.round(this.minecraft.player.getCurrentMood() * 100.0f)));
        return list;
    }

    private static String printBiome(Holder<Biome> holder) {
        return holder.unwrap().map(resourceKey -> resourceKey.location().toString(), biome -> "[unregistered " + String.valueOf(biome) + "]");
    }

    @Nullable
    private ServerLevel getServerLevel() {
        IntegratedServer integratedServer = this.minecraft.getSingleplayerServer();
        if (integratedServer != null) {
            return integratedServer.getLevel(this.minecraft.level.dimension());
        }
        return null;
    }

    @Nullable
    private String getServerChunkStats() {
        ServerLevel serverLevel = this.getServerLevel();
        if (serverLevel != null) {
            return serverLevel.gatherChunkSourceStats();
        }
        return null;
    }

    private Level getLevel() {
        return DataFixUtils.orElse(Optional.ofNullable(this.minecraft.getSingleplayerServer()).flatMap(integratedServer -> Optional.ofNullable(integratedServer.getLevel(this.minecraft.level.dimension()))), this.minecraft.level);
    }

    @Nullable
    private LevelChunk getServerChunk() {
        if (this.serverChunk == null) {
            ServerLevel serverLevel = this.getServerLevel();
            if (serverLevel == null) {
                return null;
            }
            this.serverChunk = serverLevel.getChunkSource().getChunkFuture(this.lastPos.x, this.lastPos.z, ChunkStatus.FULL, false).thenApply(chunkResult -> chunkResult.orElse(null));
        }
        return this.serverChunk.getNow(null);
    }

    private LevelChunk getClientChunk() {
        if (this.clientChunk == null) {
            this.clientChunk = this.minecraft.level.getChunk(this.lastPos.x, this.lastPos.z);
        }
        return this.clientChunk;
    }

    protected List<String> getSystemInformation() {
        Entity entity;
        BlockPos blockPos;
        long l = Runtime.getRuntime().maxMemory();
        long m = Runtime.getRuntime().totalMemory();
        long n = Runtime.getRuntime().freeMemory();
        long o = m - n;
        GpuDevice gpuDevice = RenderSystem.getDevice();
        ArrayList<String> list = Lists.newArrayList(String.format(Locale.ROOT, "Java: %s", System.getProperty("java.version")), String.format(Locale.ROOT, "Mem: %2d%% %03d/%03dMB", o * 100L / l, DebugScreenOverlay.bytesToMegabytes(o), DebugScreenOverlay.bytesToMegabytes(l)), String.format(Locale.ROOT, "Allocation rate: %03dMB/s", DebugScreenOverlay.bytesToMegabytes(this.allocationRateCalculator.bytesAllocatedPerSecond(o))), String.format(Locale.ROOT, "Allocated: %2d%% %03dMB", m * 100L / l, DebugScreenOverlay.bytesToMegabytes(m)), "", String.format(Locale.ROOT, "CPU: %s", GLX._getCpuInfo()), "", String.format(Locale.ROOT, "Display: %dx%d (%s)", Minecraft.getInstance().getWindow().getWidth(), Minecraft.getInstance().getWindow().getHeight(), gpuDevice.getVendor()), gpuDevice.getRenderer(), String.format(Locale.ROOT, "%s %s", gpuDevice.getBackendName(), gpuDevice.getVersion()));
        if (this.minecraft.showOnlyReducedInfo()) {
            return list;
        }
        if (this.block.getType() == HitResult.Type.BLOCK) {
            blockPos = ((BlockHitResult)this.block).getBlockPos();
            BlockState blockState = this.minecraft.level.getBlockState(blockPos);
            list.add("");
            list.add(String.valueOf(ChatFormatting.UNDERLINE) + "Targeted Block: " + blockPos.getX() + ", " + blockPos.getY() + ", " + blockPos.getZ());
            list.add(String.valueOf(BuiltInRegistries.BLOCK.getKey(blockState.getBlock())));
            for (Map.Entry<Property<?>, Comparable<?>> entry : blockState.getValues().entrySet()) {
                list.add(this.getPropertyValueString(entry));
            }
            blockState.getTags().map(tagKey -> "#" + String.valueOf(tagKey.location())).forEach(list::add);
        }
        if (this.liquid.getType() == HitResult.Type.BLOCK) {
            blockPos = ((BlockHitResult)this.liquid).getBlockPos();
            FluidState fluidState = this.minecraft.level.getFluidState(blockPos);
            list.add("");
            list.add(String.valueOf(ChatFormatting.UNDERLINE) + "Targeted Fluid: " + blockPos.getX() + ", " + blockPos.getY() + ", " + blockPos.getZ());
            list.add(String.valueOf(BuiltInRegistries.FLUID.getKey(fluidState.getType())));
            for (Map.Entry<Property<?>, Comparable<?>> entry : fluidState.getValues().entrySet()) {
                list.add(this.getPropertyValueString(entry));
            }
            fluidState.getTags().map(tagKey -> "#" + String.valueOf(tagKey.location())).forEach(list::add);
        }
        if ((entity = this.minecraft.crosshairPickEntity) != null) {
            list.add("");
            list.add(String.valueOf(ChatFormatting.UNDERLINE) + "Targeted Entity");
            list.add(String.valueOf(BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType())));
        }
        return list;
    }

    private String getPropertyValueString(Map.Entry<Property<?>, Comparable<?>> entry) {
        Property<?> property = entry.getKey();
        Comparable<?> comparable = entry.getValue();
        Object string = Util.getPropertyName(property, comparable);
        if (Boolean.TRUE.equals(comparable)) {
            string = String.valueOf(ChatFormatting.GREEN) + (String)string;
        } else if (Boolean.FALSE.equals(comparable)) {
            string = String.valueOf(ChatFormatting.RED) + (String)string;
        }
        return property.getName() + ": " + (String)string;
    }

    private static long bytesToMegabytes(long l) {
        return l / 1024L / 1024L;
    }

    public boolean showDebugScreen() {
        return this.renderDebug && !this.minecraft.options.hideGui;
    }

    public boolean showProfilerChart() {
        return this.showDebugScreen() && this.renderProfilerChart;
    }

    public boolean showNetworkCharts() {
        return this.showDebugScreen() && this.renderNetworkCharts;
    }

    public boolean showFpsCharts() {
        return this.showDebugScreen() && this.renderFpsCharts;
    }

    public void toggleOverlay() {
        this.renderDebug = !this.renderDebug;
    }

    public void toggleNetworkCharts() {
        boolean bl = this.renderNetworkCharts = !this.renderDebug || !this.renderNetworkCharts;
        if (this.renderNetworkCharts) {
            this.renderDebug = true;
            this.renderFpsCharts = false;
        }
    }

    public void toggleFpsCharts() {
        boolean bl = this.renderFpsCharts = !this.renderDebug || !this.renderFpsCharts;
        if (this.renderFpsCharts) {
            this.renderDebug = true;
            this.renderNetworkCharts = false;
        }
    }

    public void toggleProfilerChart() {
        boolean bl = this.renderProfilerChart = !this.renderDebug || !this.renderProfilerChart;
        if (this.renderProfilerChart) {
            this.renderDebug = true;
        }
    }

    public void logFrameDuration(long l) {
        this.frameTimeLogger.logSample(l);
    }

    public LocalSampleLogger getTickTimeLogger() {
        return this.tickTimeLogger;
    }

    public LocalSampleLogger getPingLogger() {
        return this.pingLogger;
    }

    public LocalSampleLogger getBandwidthLogger() {
        return this.bandwidthLogger;
    }

    public ProfilerPieChart getProfilerPieChart() {
        return this.profilerPieChart;
    }

    public void logRemoteSample(long[] ls, RemoteDebugSampleType remoteDebugSampleType) {
        LocalSampleLogger localSampleLogger = this.remoteSupportingLoggers.get((Object)remoteDebugSampleType);
        if (localSampleLogger != null) {
            localSampleLogger.logFullSample(ls);
        }
    }

    public void reset() {
        this.renderDebug = false;
        this.tickTimeLogger.reset();
        this.pingLogger.reset();
        this.bandwidthLogger.reset();
    }

    public void render3dCrosshair(Camera camera) {
        Matrix4fStack matrix4fStack = RenderSystem.getModelViewStack();
        matrix4fStack.pushMatrix();
        matrix4fStack.translate(0.0f, 0.0f, -1.0f);
        matrix4fStack.rotateX(camera.getXRot() * ((float)Math.PI / 180));
        matrix4fStack.rotateY(camera.getYRot() * ((float)Math.PI / 180));
        float f = 0.01f * (float)this.minecraft.getWindow().getGuiScale();
        matrix4fStack.scale(-f, f, -f);
        RenderPipeline renderPipeline = RenderPipelines.LINES;
        RenderTarget renderTarget = Minecraft.getInstance().getMainRenderTarget();
        GpuTextureView gpuTextureView = renderTarget.getColorTextureView();
        GpuTextureView gpuTextureView2 = renderTarget.getDepthTextureView();
        GpuBuffer gpuBuffer = this.crosshairIndicies.getBuffer(18);
        GpuBufferSlice[] gpuBufferSlices = RenderSystem.getDynamicUniforms().writeTransforms(new DynamicUniforms.Transform(new Matrix4f(matrix4fStack), new Vector4f(0.0f, 0.0f, 0.0f, 1.0f), new Vector3f(), new Matrix4f(), 4.0f), new DynamicUniforms.Transform(new Matrix4f(matrix4fStack), new Vector4f(1.0f, 1.0f, 1.0f, 1.0f), new Vector3f(), new Matrix4f(), 2.0f));
        try (RenderPass renderPass = RenderSystem.getDevice().createCommandEncoder().createRenderPass(() -> "3d crosshair", gpuTextureView, OptionalInt.empty(), gpuTextureView2, OptionalDouble.empty());){
            renderPass.setPipeline(renderPipeline);
            RenderSystem.bindDefaultUniforms(renderPass);
            renderPass.setVertexBuffer(0, this.crosshairBuffer);
            renderPass.setIndexBuffer(gpuBuffer, this.crosshairIndicies.type());
            renderPass.setUniform("DynamicTransforms", gpuBufferSlices[0]);
            renderPass.drawIndexed(0, 0, 18, 1);
            renderPass.setUniform("DynamicTransforms", gpuBufferSlices[1]);
            renderPass.drawIndexed(0, 0, 18, 1);
        }
        matrix4fStack.popMatrix();
    }

    @Environment(value=EnvType.CLIENT)
    static class AllocationRateCalculator {
        private static final int UPDATE_INTERVAL_MS = 500;
        private static final List<GarbageCollectorMXBean> GC_MBEANS = ManagementFactory.getGarbageCollectorMXBeans();
        private long lastTime = 0L;
        private long lastHeapUsage = -1L;
        private long lastGcCounts = -1L;
        private long lastRate = 0L;

        AllocationRateCalculator() {
        }

        long bytesAllocatedPerSecond(long l) {
            long m = System.currentTimeMillis();
            if (m - this.lastTime < 500L) {
                return this.lastRate;
            }
            long n = AllocationRateCalculator.gcCounts();
            if (this.lastTime != 0L && n == this.lastGcCounts) {
                double d = (double)TimeUnit.SECONDS.toMillis(1L) / (double)(m - this.lastTime);
                long o = l - this.lastHeapUsage;
                this.lastRate = Math.round((double)o * d);
            }
            this.lastTime = m;
            this.lastHeapUsage = l;
            this.lastGcCounts = n;
            return this.lastRate;
        }

        private static long gcCounts() {
            long l = 0L;
            for (GarbageCollectorMXBean garbageCollectorMXBean : GC_MBEANS) {
                l += garbageCollectorMXBean.getCollectionCount();
            }
            return l;
        }
    }
}

