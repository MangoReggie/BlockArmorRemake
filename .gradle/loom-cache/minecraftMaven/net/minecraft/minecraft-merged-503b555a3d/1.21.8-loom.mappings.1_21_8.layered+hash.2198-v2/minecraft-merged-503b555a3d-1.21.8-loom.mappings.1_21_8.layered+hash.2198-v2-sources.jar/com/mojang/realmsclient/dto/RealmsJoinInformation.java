/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.realmsclient.dto;

import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.dto.GuardedSerializer;
import com.mojang.realmsclient.dto.RealmsRegion;
import com.mojang.realmsclient.dto.ReflectionBasedSerialization;
import com.mojang.realmsclient.dto.ServiceQuality;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

@Environment(value=EnvType.CLIENT)
public record RealmsJoinInformation(@Nullable @SerializedName(value="address") String address, @Nullable @SerializedName(value="resourcePackUrl") String resourcePackUrl, @Nullable @SerializedName(value="resourcePackHash") String resourcePackHash, @Nullable @SerializedName(value="sessionRegionData") RegionData regionData) implements ReflectionBasedSerialization
{
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final RealmsJoinInformation EMPTY = new RealmsJoinInformation(null, null, null, null);

    public static RealmsJoinInformation parse(GuardedSerializer guardedSerializer, String string) {
        try {
            RealmsJoinInformation realmsJoinInformation = guardedSerializer.fromJson(string, RealmsJoinInformation.class);
            if (realmsJoinInformation == null) {
                LOGGER.error("Could not parse RealmsServerAddress: {}", (Object)string);
                return EMPTY;
            }
            return realmsJoinInformation;
        } catch (Exception exception) {
            LOGGER.error("Could not parse RealmsServerAddress: {}", (Object)exception.getMessage());
            return EMPTY;
        }
    }

    @SerializedName(value="address")
    @Nullable
    public String address() {
        return this.address;
    }

    @SerializedName(value="resourcePackUrl")
    @Nullable
    public String resourcePackUrl() {
        return this.resourcePackUrl;
    }

    @SerializedName(value="resourcePackHash")
    @Nullable
    public String resourcePackHash() {
        return this.resourcePackHash;
    }

    @SerializedName(value="sessionRegionData")
    @Nullable
    public RegionData regionData() {
        return this.regionData;
    }

    @Environment(value=EnvType.CLIENT)
    public record RegionData(@Nullable @SerializedName(value="regionName") @JsonAdapter(value=RealmsRegion.RealmsRegionJsonAdapter.class) RealmsRegion region, @Nullable @SerializedName(value="serviceQuality") @JsonAdapter(value=ServiceQuality.RealmsServiceQualityJsonAdapter.class) ServiceQuality serviceQuality) implements ReflectionBasedSerialization
    {
        @SerializedName(value="regionName")
        @Nullable
        public RealmsRegion region() {
            return this.region;
        }

        @SerializedName(value="serviceQuality")
        @Nullable
        public ServiceQuality serviceQuality() {
            return this.serviceQuality;
        }
    }
}

