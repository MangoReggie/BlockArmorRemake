/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.advancements.critereon;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

public interface MinMaxBounds<T extends Number> {
    public static final SimpleCommandExceptionType ERROR_EMPTY = new SimpleCommandExceptionType(Component.translatable("argument.range.empty"));
    public static final SimpleCommandExceptionType ERROR_SWAPPED = new SimpleCommandExceptionType(Component.translatable("argument.range.swapped"));

    public Optional<T> min();

    public Optional<T> max();

    default public boolean isAny() {
        return this.min().isEmpty() && this.max().isEmpty();
    }

    default public Optional<T> unwrapPoint() {
        Optional<T> optional2;
        Optional<T> optional = this.min();
        return optional.equals(optional2 = this.max()) ? optional : Optional.empty();
    }

    public static <T extends Number, R extends MinMaxBounds<T>> Codec<R> createCodec(Codec<T> codec, BoundsFactory<T, R> boundsFactory) {
        Codec codec2 = RecordCodecBuilder.create(instance -> instance.group(codec.optionalFieldOf("min").forGetter(MinMaxBounds::min), codec.optionalFieldOf("max").forGetter(MinMaxBounds::max)).apply((Applicative<MinMaxBounds, ?>)instance, boundsFactory::create));
        return Codec.either(codec2, codec).xmap(either -> either.map(minMaxBounds -> minMaxBounds, number -> boundsFactory.create(Optional.of(number), Optional.of(number))), minMaxBounds -> {
            Optional optional = minMaxBounds.unwrapPoint();
            return optional.isPresent() ? Either.right((Number)optional.get()) : Either.left(minMaxBounds);
        });
    }

    public static <B extends ByteBuf, T extends Number, R extends MinMaxBounds<T>> StreamCodec<B, R> createStreamCodec(final StreamCodec<B, T> streamCodec, final BoundsFactory<T, R> boundsFactory) {
        return new StreamCodec<B, R>(){
            private static final int MIN_FLAG = 1;
            public static final int MAX_FLAG = 2;

            @Override
            public R decode(B byteBuf) {
                byte b = ((ByteBuf)byteBuf).readByte();
                Optional optional = (b & 1) != 0 ? Optional.of((Number)streamCodec.decode(byteBuf)) : Optional.empty();
                Optional optional2 = (b & 2) != 0 ? Optional.of((Number)streamCodec.decode(byteBuf)) : Optional.empty();
                return boundsFactory.create(optional, optional2);
            }

            @Override
            public void encode(B byteBuf, R minMaxBounds) {
                Optional<Number> optional = minMaxBounds.min();
                Optional<Number> optional2 = minMaxBounds.max();
                ((ByteBuf)byteBuf).writeByte((optional.isPresent() ? 1 : 0) | (optional2.isPresent() ? 2 : 0));
                optional.ifPresent(number -> streamCodec.encode(byteBuf, number));
                optional2.ifPresent(number -> streamCodec.encode(byteBuf, number));
            }

            @Override
            public /* synthetic */ void encode(Object object, Object object2) {
                this.encode((B)((ByteBuf)object), (R)((MinMaxBounds)object2));
            }

            @Override
            public /* synthetic */ Object decode(Object object) {
                return this.decode((B)((ByteBuf)object));
            }
        };
    }

    public static <T extends Number, R extends MinMaxBounds<T>> R fromReader(StringReader stringReader, BoundsFromReaderFactory<T, R> boundsFromReaderFactory, Function<String, T> function, Supplier<DynamicCommandExceptionType> supplier, Function<T, T> function2) throws CommandSyntaxException {
        if (!stringReader.canRead()) {
            throw ERROR_EMPTY.createWithContext(stringReader);
        }
        int i = stringReader.getCursor();
        try {
            Optional<T> optional2;
            Optional<T> optional = MinMaxBounds.readNumber(stringReader, function, supplier).map(function2);
            if (stringReader.canRead(2) && stringReader.peek() == '.' && stringReader.peek(1) == '.') {
                stringReader.skip();
                stringReader.skip();
                optional2 = MinMaxBounds.readNumber(stringReader, function, supplier).map(function2);
                if (optional.isEmpty() && optional2.isEmpty()) {
                    throw ERROR_EMPTY.createWithContext(stringReader);
                }
            } else {
                optional2 = optional;
            }
            if (optional.isEmpty() && optional2.isEmpty()) {
                throw ERROR_EMPTY.createWithContext(stringReader);
            }
            return boundsFromReaderFactory.create(stringReader, optional, optional2);
        } catch (CommandSyntaxException commandSyntaxException) {
            stringReader.setCursor(i);
            throw new CommandSyntaxException(commandSyntaxException.getType(), commandSyntaxException.getRawMessage(), commandSyntaxException.getInput(), i);
        }
    }

    private static <T extends Number> Optional<T> readNumber(StringReader stringReader, Function<String, T> function, Supplier<DynamicCommandExceptionType> supplier) throws CommandSyntaxException {
        int i = stringReader.getCursor();
        while (stringReader.canRead() && MinMaxBounds.isAllowedInputChat(stringReader)) {
            stringReader.skip();
        }
        String string = stringReader.getString().substring(i, stringReader.getCursor());
        if (string.isEmpty()) {
            return Optional.empty();
        }
        try {
            return Optional.of((Number)function.apply(string));
        } catch (NumberFormatException numberFormatException) {
            throw supplier.get().createWithContext(stringReader, string);
        }
    }

    private static boolean isAllowedInputChat(StringReader stringReader) {
        char c = stringReader.peek();
        if (c >= '0' && c <= '9' || c == '-') {
            return true;
        }
        if (c == '.') {
            return !stringReader.canRead(2) || stringReader.peek(1) != '.';
        }
        return false;
    }

    @FunctionalInterface
    public static interface BoundsFactory<T extends Number, R extends MinMaxBounds<T>> {
        public R create(Optional<T> var1, Optional<T> var2);
    }

    @FunctionalInterface
    public static interface BoundsFromReaderFactory<T extends Number, R extends MinMaxBounds<T>> {
        public R create(StringReader var1, Optional<T> var2, Optional<T> var3) throws CommandSyntaxException;
    }

    public record Doubles(Optional<Double> min, Optional<Double> max, Optional<Double> minSq, Optional<Double> maxSq) implements MinMaxBounds<Double>
    {
        public static final Doubles ANY = new Doubles(Optional.empty(), Optional.empty());
        public static final Codec<Doubles> CODEC = MinMaxBounds.createCodec(Codec.DOUBLE, Doubles::new);
        public static final StreamCodec<ByteBuf, Doubles> STREAM_CODEC = MinMaxBounds.createStreamCodec(ByteBufCodecs.DOUBLE, Doubles::new);

        private Doubles(Optional<Double> optional, Optional<Double> optional2) {
            this(optional, optional2, Doubles.squareOpt(optional), Doubles.squareOpt(optional2));
        }

        private static Doubles create(StringReader stringReader, Optional<Double> optional, Optional<Double> optional2) throws CommandSyntaxException {
            if (optional.isPresent() && optional2.isPresent() && optional.get() > optional2.get()) {
                throw ERROR_SWAPPED.createWithContext(stringReader);
            }
            return new Doubles(optional, optional2);
        }

        private static Optional<Double> squareOpt(Optional<Double> optional) {
            return optional.map(double_ -> double_ * double_);
        }

        public static Doubles exactly(double d) {
            return new Doubles(Optional.of(d), Optional.of(d));
        }

        public static Doubles between(double d, double e) {
            return new Doubles(Optional.of(d), Optional.of(e));
        }

        public static Doubles atLeast(double d) {
            return new Doubles(Optional.of(d), Optional.empty());
        }

        public static Doubles atMost(double d) {
            return new Doubles(Optional.empty(), Optional.of(d));
        }

        public boolean matches(double d) {
            if (this.min.isPresent() && this.min.get() > d) {
                return false;
            }
            return this.max.isEmpty() || !(this.max.get() < d);
        }

        public boolean matchesSqr(double d) {
            if (this.minSq.isPresent() && this.minSq.get() > d) {
                return false;
            }
            return this.maxSq.isEmpty() || !(this.maxSq.get() < d);
        }

        public static Doubles fromReader(StringReader stringReader) throws CommandSyntaxException {
            return Doubles.fromReader(stringReader, double_ -> double_);
        }

        public static Doubles fromReader(StringReader stringReader, Function<Double, Double> function) throws CommandSyntaxException {
            return MinMaxBounds.fromReader(stringReader, Doubles::create, Double::parseDouble, CommandSyntaxException.BUILT_IN_EXCEPTIONS::readerInvalidDouble, function);
        }
    }

    public record Ints(Optional<Integer> min, Optional<Integer> max, Optional<Long> minSq, Optional<Long> maxSq) implements MinMaxBounds<Integer>
    {
        public static final Ints ANY = new Ints(Optional.empty(), Optional.empty());
        public static final Codec<Ints> CODEC = MinMaxBounds.createCodec(Codec.INT, Ints::new);
        public static final StreamCodec<ByteBuf, Ints> STREAM_CODEC = MinMaxBounds.createStreamCodec(ByteBufCodecs.INT, Ints::new);

        private Ints(Optional<Integer> optional, Optional<Integer> optional2) {
            this(optional, optional2, optional.map(integer -> integer.longValue() * integer.longValue()), Ints.squareOpt(optional2));
        }

        private static Ints create(StringReader stringReader, Optional<Integer> optional, Optional<Integer> optional2) throws CommandSyntaxException {
            if (optional.isPresent() && optional2.isPresent() && optional.get() > optional2.get()) {
                throw ERROR_SWAPPED.createWithContext(stringReader);
            }
            return new Ints(optional, optional2);
        }

        private static Optional<Long> squareOpt(Optional<Integer> optional) {
            return optional.map(integer -> integer.longValue() * integer.longValue());
        }

        public static Ints exactly(int i) {
            return new Ints(Optional.of(i), Optional.of(i));
        }

        public static Ints between(int i, int j) {
            return new Ints(Optional.of(i), Optional.of(j));
        }

        public static Ints atLeast(int i) {
            return new Ints(Optional.of(i), Optional.empty());
        }

        public static Ints atMost(int i) {
            return new Ints(Optional.empty(), Optional.of(i));
        }

        public boolean matches(int i) {
            if (this.min.isPresent() && this.min.get() > i) {
                return false;
            }
            return this.max.isEmpty() || this.max.get() >= i;
        }

        public boolean matchesSqr(long l) {
            if (this.minSq.isPresent() && this.minSq.get() > l) {
                return false;
            }
            return this.maxSq.isEmpty() || this.maxSq.get() >= l;
        }

        public static Ints fromReader(StringReader stringReader) throws CommandSyntaxException {
            return Ints.fromReader(stringReader, integer -> integer);
        }

        public static Ints fromReader(StringReader stringReader, Function<Integer, Integer> function) throws CommandSyntaxException {
            return MinMaxBounds.fromReader(stringReader, Ints::create, Integer::parseInt, CommandSyntaxException.BUILT_IN_EXCEPTIONS::readerInvalidInt, function);
        }
    }
}

