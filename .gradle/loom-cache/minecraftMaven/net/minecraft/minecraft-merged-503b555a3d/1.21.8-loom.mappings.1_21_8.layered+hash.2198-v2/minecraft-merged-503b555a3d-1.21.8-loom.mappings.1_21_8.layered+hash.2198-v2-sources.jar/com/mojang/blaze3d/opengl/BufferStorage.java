/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.blaze3d.opengl;

import com.mojang.blaze3d.opengl.DirectStateAccess;
import com.mojang.blaze3d.opengl.GlBuffer;
import com.mojang.blaze3d.opengl.GlConst;
import com.mojang.blaze3d.opengl.GlDevice;
import com.mojang.blaze3d.opengl.GlStateManager;
import java.nio.ByteBuffer;
import java.util.Set;
import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.opengl.GLCapabilities;
import org.lwjgl.system.MemoryUtil;

@Environment(value=EnvType.CLIENT)
public abstract class BufferStorage {
    public static BufferStorage create(GLCapabilities gLCapabilities, Set<String> set) {
        if (gLCapabilities.GL_ARB_buffer_storage && GlDevice.USE_GL_ARB_buffer_storage) {
            set.add("GL_ARB_buffer_storage");
            return new Immutable();
        }
        return new Mutable();
    }

    public abstract GlBuffer createBuffer(DirectStateAccess var1, @Nullable Supplier<String> var2, int var3, int var4);

    public abstract GlBuffer createBuffer(DirectStateAccess var1, @Nullable Supplier<String> var2, int var3, ByteBuffer var4);

    public abstract GlBuffer.GlMappedView mapBuffer(DirectStateAccess var1, GlBuffer var2, int var3, int var4, int var5);

    @Environment(value=EnvType.CLIENT)
    static class Immutable
    extends BufferStorage {
        Immutable() {
        }

        @Override
        public GlBuffer createBuffer(DirectStateAccess directStateAccess, @Nullable Supplier<String> supplier, int i, int j) {
            int k = directStateAccess.createBuffer();
            directStateAccess.bufferStorage(k, j, GlConst.bufferUsageToGlFlag(i));
            ByteBuffer byteBuffer = this.tryMapBufferPersistent(directStateAccess, i, k, j);
            return new GlBuffer(supplier, directStateAccess, i, j, k, byteBuffer);
        }

        @Override
        public GlBuffer createBuffer(DirectStateAccess directStateAccess, @Nullable Supplier<String> supplier, int i, ByteBuffer byteBuffer) {
            int j = directStateAccess.createBuffer();
            int k = byteBuffer.remaining();
            directStateAccess.bufferStorage(j, byteBuffer, GlConst.bufferUsageToGlFlag(i));
            ByteBuffer byteBuffer2 = this.tryMapBufferPersistent(directStateAccess, i, j, k);
            return new GlBuffer(supplier, directStateAccess, i, k, j, byteBuffer2);
        }

        @Nullable
        private ByteBuffer tryMapBufferPersistent(DirectStateAccess directStateAccess, int i, int j, int k) {
            ByteBuffer byteBuffer;
            int l = 0;
            if ((i & 1) != 0) {
                l |= 1;
            }
            if ((i & 2) != 0) {
                l |= 0x12;
            }
            if (l != 0) {
                GlStateManager.clearGlErrors();
                byteBuffer = directStateAccess.mapBufferRange(j, 0, k, l | 0x40);
                if (byteBuffer == null) {
                    throw new IllegalStateException("Can't persistently map buffer, opengl error " + GlStateManager._getError());
                }
            } else {
                byteBuffer = null;
            }
            return byteBuffer;
        }

        @Override
        public GlBuffer.GlMappedView mapBuffer(DirectStateAccess directStateAccess, GlBuffer glBuffer, int i, int j, int k) {
            if (glBuffer.persistentBuffer == null) {
                throw new IllegalStateException("Somehow trying to map an unmappable buffer");
            }
            return new GlBuffer.GlMappedView(() -> {
                if ((k & 2) != 0) {
                    directStateAccess.flushMappedBufferRange(glBuffer.handle, i, j);
                }
            }, glBuffer, MemoryUtil.memSlice(glBuffer.persistentBuffer, i, j));
        }
    }

    @Environment(value=EnvType.CLIENT)
    static class Mutable
    extends BufferStorage {
        Mutable() {
        }

        @Override
        public GlBuffer createBuffer(DirectStateAccess directStateAccess, @Nullable Supplier<String> supplier, int i, int j) {
            int k = directStateAccess.createBuffer();
            directStateAccess.bufferData(k, j, GlConst.bufferUsageToGlEnum(i));
            return new GlBuffer(supplier, directStateAccess, i, j, k, null);
        }

        @Override
        public GlBuffer createBuffer(DirectStateAccess directStateAccess, @Nullable Supplier<String> supplier, int i, ByteBuffer byteBuffer) {
            int j = directStateAccess.createBuffer();
            int k = byteBuffer.remaining();
            directStateAccess.bufferData(j, byteBuffer, GlConst.bufferUsageToGlEnum(i));
            return new GlBuffer(supplier, directStateAccess, i, k, j, null);
        }

        @Override
        public GlBuffer.GlMappedView mapBuffer(DirectStateAccess directStateAccess, GlBuffer glBuffer, int i, int j, int k) {
            GlStateManager.clearGlErrors();
            ByteBuffer byteBuffer = directStateAccess.mapBufferRange(glBuffer.handle, i, j, k);
            if (byteBuffer == null) {
                throw new IllegalStateException("Can't map buffer, opengl error " + GlStateManager._getError());
            }
            return new GlBuffer.GlMappedView(() -> directStateAccess.unmapBuffer(glBuffer.handle), glBuffer, byteBuffer);
        }
    }
}

