/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.blaze3d.pipeline;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jetbrains.annotations.Nullable;

@Environment(value=EnvType.CLIENT)
public class TextureTarget
extends RenderTarget {
    public TextureTarget(@Nullable String string, int i, int j, boolean bl) {
        super(string, bl);
        RenderSystem.assertOnRenderThread();
        this.resize(i, j);
    }
}

