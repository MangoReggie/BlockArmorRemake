/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.blaze3d.opengl;

import com.mojang.blaze3d.opengl.GlConst;
import com.mojang.blaze3d.opengl.GlDevice;
import com.mojang.blaze3d.opengl.GlStateManager;
import java.nio.ByteBuffer;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.opengl.ARBBufferStorage;
import org.lwjgl.opengl.ARBDirectStateAccess;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL31;
import org.lwjgl.opengl.GLCapabilities;

@Environment(value=EnvType.CLIENT)
public abstract class DirectStateAccess {
    public static DirectStateAccess create(GLCapabilities gLCapabilities, Set<String> set) {
        if (gLCapabilities.GL_ARB_direct_state_access && GlDevice.USE_GL_ARB_direct_state_access) {
            set.add("GL_ARB_direct_state_access");
            return new Core();
        }
        return new Emulated();
    }

    abstract int createBuffer();

    abstract void bufferData(int var1, long var2, int var4);

    abstract void bufferData(int var1, ByteBuffer var2, int var3);

    abstract void bufferSubData(int var1, int var2, ByteBuffer var3);

    abstract void bufferStorage(int var1, long var2, int var4);

    abstract void bufferStorage(int var1, ByteBuffer var2, int var3);

    @Nullable
    abstract ByteBuffer mapBufferRange(int var1, int var2, int var3, int var4);

    abstract void unmapBuffer(int var1);

    abstract int createFrameBufferObject();

    abstract void bindFrameBufferTextures(int var1, int var2, int var3, int var4, int var5);

    abstract void blitFrameBuffers(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11, int var12);

    abstract void flushMappedBufferRange(int var1, int var2, int var3);

    abstract void copyBufferSubData(int var1, int var2, int var3, int var4, int var5);

    @Environment(value=EnvType.CLIENT)
    static class Core
    extends DirectStateAccess {
        Core() {
        }

        @Override
        int createBuffer() {
            return ARBDirectStateAccess.glCreateBuffers();
        }

        @Override
        void bufferData(int i, long l, int j) {
            ARBDirectStateAccess.glNamedBufferData(i, l, j);
        }

        @Override
        void bufferData(int i, ByteBuffer byteBuffer, int j) {
            ARBDirectStateAccess.glNamedBufferData(i, byteBuffer, j);
        }

        @Override
        void bufferSubData(int i, int j, ByteBuffer byteBuffer) {
            ARBDirectStateAccess.glNamedBufferSubData(i, (long)j, byteBuffer);
        }

        @Override
        void bufferStorage(int i, long l, int j) {
            ARBDirectStateAccess.glNamedBufferStorage(i, l, j);
        }

        @Override
        void bufferStorage(int i, ByteBuffer byteBuffer, int j) {
            ARBDirectStateAccess.glNamedBufferStorage(i, byteBuffer, j);
        }

        @Override
        @Nullable
        ByteBuffer mapBufferRange(int i, int j, int k, int l) {
            return ARBDirectStateAccess.glMapNamedBufferRange(i, j, k, l);
        }

        @Override
        void unmapBuffer(int i) {
            ARBDirectStateAccess.glUnmapNamedBuffer(i);
        }

        @Override
        public int createFrameBufferObject() {
            return ARBDirectStateAccess.glCreateFramebuffers();
        }

        @Override
        public void bindFrameBufferTextures(int i, int j, int k, int l, int m) {
            ARBDirectStateAccess.glNamedFramebufferTexture(i, 36064, j, l);
            ARBDirectStateAccess.glNamedFramebufferTexture(i, 36096, k, l);
            if (m != 0) {
                GlStateManager._glBindFramebuffer(m, i);
            }
        }

        @Override
        public void blitFrameBuffers(int i, int j, int k, int l, int m, int n, int o, int p, int q, int r, int s, int t) {
            ARBDirectStateAccess.glBlitNamedFramebuffer(i, j, k, l, m, n, o, p, q, r, s, t);
        }

        @Override
        void flushMappedBufferRange(int i, int j, int k) {
            ARBDirectStateAccess.glFlushMappedNamedBufferRange(i, j, k);
        }

        @Override
        void copyBufferSubData(int i, int j, int k, int l, int m) {
            ARBDirectStateAccess.glCopyNamedBufferSubData(i, j, k, l, m);
        }
    }

    @Environment(value=EnvType.CLIENT)
    static class Emulated
    extends DirectStateAccess {
        Emulated() {
        }

        @Override
        int createBuffer() {
            return GlStateManager._glGenBuffers();
        }

        @Override
        void bufferData(int i, long l, int j) {
            GlStateManager._glBindBuffer(36663, i);
            GlStateManager._glBufferData(36663, l, GlConst.bufferUsageToGlEnum(j));
            GlStateManager._glBindBuffer(36663, 0);
        }

        @Override
        void bufferData(int i, ByteBuffer byteBuffer, int j) {
            GlStateManager._glBindBuffer(36663, i);
            GlStateManager._glBufferData(36663, byteBuffer, GlConst.bufferUsageToGlEnum(j));
            GlStateManager._glBindBuffer(36663, 0);
        }

        @Override
        void bufferSubData(int i, int j, ByteBuffer byteBuffer) {
            GlStateManager._glBindBuffer(36663, i);
            GlStateManager._glBufferSubData(36663, j, byteBuffer);
            GlStateManager._glBindBuffer(36663, 0);
        }

        @Override
        void bufferStorage(int i, long l, int j) {
            GlStateManager._glBindBuffer(36663, i);
            ARBBufferStorage.glBufferStorage(36663, l, j);
            GlStateManager._glBindBuffer(36663, 0);
        }

        @Override
        void bufferStorage(int i, ByteBuffer byteBuffer, int j) {
            GlStateManager._glBindBuffer(36663, i);
            ARBBufferStorage.glBufferStorage(36663, byteBuffer, j);
            GlStateManager._glBindBuffer(36663, 0);
        }

        @Override
        @Nullable
        ByteBuffer mapBufferRange(int i, int j, int k, int l) {
            GlStateManager._glBindBuffer(36663, i);
            ByteBuffer byteBuffer = GlStateManager._glMapBufferRange(36663, j, k, l);
            GlStateManager._glBindBuffer(36663, 0);
            return byteBuffer;
        }

        @Override
        void unmapBuffer(int i) {
            GlStateManager._glBindBuffer(36663, i);
            GlStateManager._glUnmapBuffer(36663);
            GlStateManager._glBindBuffer(36663, 0);
        }

        @Override
        void flushMappedBufferRange(int i, int j, int k) {
            GlStateManager._glBindBuffer(36663, i);
            GL30.glFlushMappedBufferRange(36663, j, k);
            GlStateManager._glBindBuffer(36663, 0);
        }

        @Override
        void copyBufferSubData(int i, int j, int k, int l, int m) {
            GlStateManager._glBindBuffer(36662, i);
            GlStateManager._glBindBuffer(36663, j);
            GL31.glCopyBufferSubData(36662, 36663, k, l, m);
            GlStateManager._glBindBuffer(36662, 0);
            GlStateManager._glBindBuffer(36663, 0);
        }

        @Override
        public int createFrameBufferObject() {
            return GlStateManager.glGenFramebuffers();
        }

        @Override
        public void bindFrameBufferTextures(int i, int j, int k, int l, int m) {
            int n = m == 0 ? 36009 : m;
            int o = GlStateManager.getFrameBuffer(n);
            GlStateManager._glBindFramebuffer(n, i);
            GlStateManager._glFramebufferTexture2D(n, 36064, 3553, j, l);
            GlStateManager._glFramebufferTexture2D(n, 36096, 3553, k, l);
            if (m == 0) {
                GlStateManager._glBindFramebuffer(n, o);
            }
        }

        @Override
        public void blitFrameBuffers(int i, int j, int k, int l, int m, int n, int o, int p, int q, int r, int s, int t) {
            int u = GlStateManager.getFrameBuffer(36008);
            int v = GlStateManager.getFrameBuffer(36009);
            GlStateManager._glBindFramebuffer(36008, i);
            GlStateManager._glBindFramebuffer(36009, j);
            GlStateManager._glBlitFrameBuffer(k, l, m, n, o, p, q, r, s, t);
            GlStateManager._glBindFramebuffer(36008, u);
            GlStateManager._glBindFramebuffer(36009, v);
        }
    }
}

