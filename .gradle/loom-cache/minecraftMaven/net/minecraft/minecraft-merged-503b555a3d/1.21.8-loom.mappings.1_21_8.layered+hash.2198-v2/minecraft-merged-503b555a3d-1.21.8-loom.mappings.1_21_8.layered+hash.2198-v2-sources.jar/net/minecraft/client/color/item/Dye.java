/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.client.color.item;

import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.color.item.ItemTintSource;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.DyedItemColor;
import org.jetbrains.annotations.Nullable;

@Environment(value=EnvType.CLIENT)
public record Dye(int defaultColor) implements ItemTintSource
{
    public static final MapCodec<Dye> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(((MapCodec)ExtraCodecs.RGB_COLOR_CODEC.fieldOf("default")).forGetter(Dye::defaultColor)).apply((Applicative<Dye, ?>)instance, Dye::new));

    @Override
    public int calculate(ItemStack itemStack, @Nullable ClientLevel clientLevel, @Nullable LivingEntity livingEntity) {
        return DyedItemColor.getOrDefault(itemStack, this.defaultColor);
    }

    public MapCodec<Dye> type() {
        return MAP_CODEC;
    }
}

