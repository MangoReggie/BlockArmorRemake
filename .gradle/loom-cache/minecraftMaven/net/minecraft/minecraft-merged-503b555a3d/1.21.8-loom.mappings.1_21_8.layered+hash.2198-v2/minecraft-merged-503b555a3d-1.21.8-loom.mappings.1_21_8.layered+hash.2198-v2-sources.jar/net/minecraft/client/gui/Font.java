/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.client.gui;

import com.ibm.icu.text.ArabicShaping;
import com.ibm.icu.text.ArabicShapingException;
import com.ibm.icu.text.Bidi;
import com.mojang.blaze3d.font.GlyphInfo;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.StringSplitter;
import net.minecraft.client.gui.font.FontSet;
import net.minecraft.client.gui.font.glyphs.BakedGlyph;
import net.minecraft.client.gui.font.glyphs.EmptyGlyph;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.locale.Language;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.ARGB;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.FormattedCharSink;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.util.StringDecomposer;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

@Environment(value=EnvType.CLIENT)
public class Font {
    private static final float EFFECT_DEPTH = 0.01f;
    private static final float OVER_EFFECT_DEPTH = 0.01f;
    private static final float UNDER_EFFECT_DEPTH = -0.01f;
    public static final float SHADOW_DEPTH = 0.03f;
    public static final int NO_SHADOW = 0;
    public final int lineHeight = 9;
    public final RandomSource random = RandomSource.create();
    private final Function<ResourceLocation, FontSet> fonts;
    final boolean filterFishyGlyphs;
    private final StringSplitter splitter;

    public Font(Function<ResourceLocation, FontSet> function, boolean bl) {
        this.fonts = function;
        this.filterFishyGlyphs = bl;
        this.splitter = new StringSplitter((i, style) -> this.getFontSet(style.getFont()).getGlyphInfo(i, this.filterFishyGlyphs).getAdvance(style.isBold()));
    }

    FontSet getFontSet(ResourceLocation resourceLocation) {
        return this.fonts.apply(resourceLocation);
    }

    public String bidirectionalShaping(String string) {
        try {
            Bidi bidi = new Bidi(new ArabicShaping(8).shape(string), 127);
            bidi.setReorderingMode(0);
            return bidi.writeReordered(2);
        } catch (ArabicShapingException arabicShapingException) {
            return string;
        }
    }

    public void drawInBatch(String string, float f, float g, int i, boolean bl, Matrix4f matrix4f, MultiBufferSource multiBufferSource, DisplayMode displayMode, int j, int k) {
        PreparedText preparedText = this.prepareText(string, f, g, i, bl, j);
        preparedText.visit(GlyphVisitor.forMultiBufferSource(multiBufferSource, matrix4f, displayMode, k));
    }

    public void drawInBatch(Component component, float f, float g, int i, boolean bl, Matrix4f matrix4f, MultiBufferSource multiBufferSource, DisplayMode displayMode, int j, int k) {
        PreparedText preparedText = this.prepareText(component.getVisualOrderText(), f, g, i, bl, j);
        preparedText.visit(GlyphVisitor.forMultiBufferSource(multiBufferSource, matrix4f, displayMode, k));
    }

    public void drawInBatch(FormattedCharSequence formattedCharSequence, float f, float g, int i, boolean bl, Matrix4f matrix4f, MultiBufferSource multiBufferSource, DisplayMode displayMode, int j, int k) {
        PreparedText preparedText = this.prepareText(formattedCharSequence, f, g, i, bl, j);
        preparedText.visit(GlyphVisitor.forMultiBufferSource(multiBufferSource, matrix4f, displayMode, k));
    }

    public void drawInBatch8xOutline(FormattedCharSequence formattedCharSequence, float f, float g, int i, int j, Matrix4f matrix4f, MultiBufferSource multiBufferSource, int k) {
        PreparedTextBuilder preparedTextBuilder = new PreparedTextBuilder(0.0f, 0.0f, j, false);
        for (int l2 = -1; l2 <= 1; ++l2) {
            for (int m2 = -1; m2 <= 1; ++m2) {
                if (l2 == 0 && m2 == 0) continue;
                float[] fs = new float[]{f};
                int n = l2;
                int o = m2;
                formattedCharSequence.accept((l, style, m) -> {
                    boolean bl = style.isBold();
                    FontSet fontSet = this.getFontSet(style.getFont());
                    GlyphInfo glyphInfo = fontSet.getGlyphInfo(m, this.filterFishyGlyphs);
                    preparedTextBuilder.x = fs[0] + (float)n * glyphInfo.getShadowOffset();
                    preparedTextBuilder.y = g + (float)o * glyphInfo.getShadowOffset();
                    fs[0] = fs[0] + glyphInfo.getAdvance(bl);
                    return preparedTextBuilder.accept(l, style.withColor(j), m);
                });
            }
        }
        GlyphVisitor glyphVisitor = GlyphVisitor.forMultiBufferSource(multiBufferSource, matrix4f, DisplayMode.NORMAL, k);
        for (BakedGlyph.GlyphInstance glyphInstance : preparedTextBuilder.glyphs) {
            glyphVisitor.acceptGlyph(glyphInstance);
        }
        PreparedTextBuilder preparedTextBuilder2 = new PreparedTextBuilder(f, g, i, false);
        formattedCharSequence.accept(preparedTextBuilder2);
        preparedTextBuilder2.visit(GlyphVisitor.forMultiBufferSource(multiBufferSource, matrix4f, DisplayMode.POLYGON_OFFSET, k));
    }

    public PreparedText prepareText(String string, float f, float g, int i, boolean bl, int j) {
        if (this.isBidirectional()) {
            string = this.bidirectionalShaping(string);
        }
        PreparedTextBuilder preparedTextBuilder = new PreparedTextBuilder(f, g, i, j, bl);
        StringDecomposer.iterateFormatted(string, Style.EMPTY, (FormattedCharSink)preparedTextBuilder);
        return preparedTextBuilder;
    }

    public PreparedText prepareText(FormattedCharSequence formattedCharSequence, float f, float g, int i, boolean bl, int j) {
        PreparedTextBuilder preparedTextBuilder = new PreparedTextBuilder(f, g, i, j, bl);
        formattedCharSequence.accept(preparedTextBuilder);
        return preparedTextBuilder;
    }

    public int width(String string) {
        return Mth.ceil(this.splitter.stringWidth(string));
    }

    public int width(FormattedText formattedText) {
        return Mth.ceil(this.splitter.stringWidth(formattedText));
    }

    public int width(FormattedCharSequence formattedCharSequence) {
        return Mth.ceil(this.splitter.stringWidth(formattedCharSequence));
    }

    public String plainSubstrByWidth(String string, int i, boolean bl) {
        return bl ? this.splitter.plainTailByWidth(string, i, Style.EMPTY) : this.splitter.plainHeadByWidth(string, i, Style.EMPTY);
    }

    public String plainSubstrByWidth(String string, int i) {
        return this.splitter.plainHeadByWidth(string, i, Style.EMPTY);
    }

    public FormattedText substrByWidth(FormattedText formattedText, int i) {
        return this.splitter.headByWidth(formattedText, i, Style.EMPTY);
    }

    public int wordWrapHeight(String string, int i) {
        return 9 * this.splitter.splitLines(string, i, Style.EMPTY).size();
    }

    public int wordWrapHeight(FormattedText formattedText, int i) {
        return 9 * this.splitter.splitLines(formattedText, i, Style.EMPTY).size();
    }

    public List<FormattedCharSequence> split(FormattedText formattedText, int i) {
        return Language.getInstance().getVisualOrder(this.splitter.splitLines(formattedText, i, Style.EMPTY));
    }

    public List<FormattedText> splitIgnoringLanguage(FormattedText formattedText, int i) {
        return this.splitter.splitLines(formattedText, i, Style.EMPTY);
    }

    public boolean isBidirectional() {
        return Language.getInstance().isDefaultRightToLeft();
    }

    public StringSplitter getSplitter() {
        return this.splitter;
    }

    @Environment(value=EnvType.CLIENT)
    public static interface PreparedText {
        public void visit(GlyphVisitor var1);

        @Nullable
        public ScreenRectangle bounds();
    }

    @Environment(value=EnvType.CLIENT)
    public static interface GlyphVisitor {
        public static GlyphVisitor forMultiBufferSource(final MultiBufferSource multiBufferSource, final Matrix4f matrix4f, final DisplayMode displayMode, final int i) {
            return new GlyphVisitor(){

                @Override
                public void acceptGlyph(BakedGlyph.GlyphInstance glyphInstance) {
                    BakedGlyph bakedGlyph = glyphInstance.glyph();
                    VertexConsumer vertexConsumer = multiBufferSource.getBuffer(bakedGlyph.renderType(displayMode));
                    bakedGlyph.renderChar(glyphInstance, matrix4f, vertexConsumer, i, false);
                }

                @Override
                public void acceptEffect(BakedGlyph bakedGlyph, BakedGlyph.Effect effect) {
                    VertexConsumer vertexConsumer = multiBufferSource.getBuffer(bakedGlyph.renderType(displayMode));
                    bakedGlyph.renderEffect(effect, matrix4f, vertexConsumer, i, false);
                }
            };
        }

        public void acceptGlyph(BakedGlyph.GlyphInstance var1);

        public void acceptEffect(BakedGlyph var1, BakedGlyph.Effect var2);
    }

    @Environment(value=EnvType.CLIENT)
    public static enum DisplayMode {
        NORMAL,
        SEE_THROUGH,
        POLYGON_OFFSET;

    }

    @Environment(value=EnvType.CLIENT)
    class PreparedTextBuilder
    implements FormattedCharSink,
    PreparedText {
        private final boolean drawShadow;
        private final int color;
        private final int backgroundColor;
        float x;
        float y;
        private float left = Float.MAX_VALUE;
        private float top = Float.MAX_VALUE;
        private float right = -3.4028235E38f;
        private float bottom = -3.4028235E38f;
        private float backgroundLeft = Float.MAX_VALUE;
        private float backgroundTop = Float.MAX_VALUE;
        private float backgroundRight = -3.4028235E38f;
        private float backgroundBottom = -3.4028235E38f;
        final List<BakedGlyph.GlyphInstance> glyphs = new ArrayList<BakedGlyph.GlyphInstance>();
        @Nullable
        private List<BakedGlyph.Effect> effects;

        public PreparedTextBuilder(float f, float g, int i, boolean bl) {
            this(f, g, i, 0, bl);
        }

        public PreparedTextBuilder(float f, float g, int i, int j, boolean bl) {
            this.x = f;
            this.y = g;
            this.drawShadow = bl;
            this.color = i;
            this.backgroundColor = j;
            this.markBackground(f, g, 0.0f);
        }

        private void markSize(float f, float g, float h, float i) {
            this.left = Math.min(this.left, f);
            this.top = Math.min(this.top, g);
            this.right = Math.max(this.right, h);
            this.bottom = Math.max(this.bottom, i);
        }

        private void markBackground(float f, float g, float h) {
            if (ARGB.alpha(this.backgroundColor) == 0) {
                return;
            }
            this.backgroundLeft = Math.min(this.backgroundLeft, f - 1.0f);
            this.backgroundTop = Math.min(this.backgroundTop, g - 1.0f);
            this.backgroundRight = Math.max(this.backgroundRight, f + h);
            this.backgroundBottom = Math.max(this.backgroundBottom, g + 9.0f);
            this.markSize(this.backgroundLeft, this.backgroundTop, this.backgroundRight, this.backgroundBottom);
        }

        private void addGlyph(BakedGlyph.GlyphInstance glyphInstance) {
            this.glyphs.add(glyphInstance);
            this.markSize(glyphInstance.left(), glyphInstance.top(), glyphInstance.right(), glyphInstance.bottom());
        }

        private void addEffect(BakedGlyph.Effect effect) {
            if (this.effects == null) {
                this.effects = new ArrayList<BakedGlyph.Effect>();
            }
            this.effects.add(effect);
            this.markSize(effect.left(), effect.top(), effect.right(), effect.bottom());
        }

        @Override
        public boolean accept(int i, Style style, int j) {
            FontSet fontSet = Font.this.getFontSet(style.getFont());
            GlyphInfo glyphInfo = fontSet.getGlyphInfo(j, Font.this.filterFishyGlyphs);
            BakedGlyph bakedGlyph = style.isObfuscated() && j != 32 ? fontSet.getRandomGlyph(glyphInfo) : fontSet.getGlyph(j);
            boolean bl = style.isBold();
            TextColor textColor = style.getColor();
            int k = this.getTextColor(textColor);
            int l = this.getShadowColor(style, k);
            float f = glyphInfo.getAdvance(bl);
            float g = i == 0 ? this.x - 1.0f : this.x;
            float h = glyphInfo.getShadowOffset();
            if (!(bakedGlyph instanceof EmptyGlyph)) {
                float m = bl ? glyphInfo.getBoldOffset() : 0.0f;
                this.addGlyph(new BakedGlyph.GlyphInstance(this.x, this.y, k, l, bakedGlyph, style, m, h));
            }
            this.markBackground(this.x, this.y, f);
            if (style.isStrikethrough()) {
                this.addEffect(new BakedGlyph.Effect(g, this.y + 4.5f - 1.0f, this.x + f, this.y + 4.5f, 0.01f, k, l, h));
            }
            if (style.isUnderlined()) {
                this.addEffect(new BakedGlyph.Effect(g, this.y + 9.0f - 1.0f, this.x + f, this.y + 9.0f, 0.01f, k, l, h));
            }
            this.x += f;
            return true;
        }

        @Override
        public void visit(GlyphVisitor glyphVisitor) {
            BakedGlyph bakedGlyph = null;
            if (ARGB.alpha(this.backgroundColor) != 0) {
                BakedGlyph.Effect effect = new BakedGlyph.Effect(this.backgroundLeft, this.backgroundTop, this.backgroundRight, this.backgroundBottom, -0.01f, this.backgroundColor);
                bakedGlyph = Font.this.getFontSet(Style.DEFAULT_FONT).whiteGlyph();
                glyphVisitor.acceptEffect(bakedGlyph, effect);
            }
            for (BakedGlyph.GlyphInstance glyphInstance : this.glyphs) {
                glyphVisitor.acceptGlyph(glyphInstance);
            }
            if (this.effects != null) {
                if (bakedGlyph == null) {
                    bakedGlyph = Font.this.getFontSet(Style.DEFAULT_FONT).whiteGlyph();
                }
                for (BakedGlyph.Effect effect2 : this.effects) {
                    glyphVisitor.acceptEffect(bakedGlyph, effect2);
                }
            }
        }

        private int getTextColor(@Nullable TextColor textColor) {
            if (textColor != null) {
                int i = ARGB.alpha(this.color);
                int j = textColor.getValue();
                return ARGB.color(i, j);
            }
            return this.color;
        }

        private int getShadowColor(Style style, int i) {
            Integer integer = style.getShadowColor();
            if (integer != null) {
                float f = ARGB.alphaFloat(i);
                float g = ARGB.alphaFloat(integer);
                if (f != 1.0f) {
                    return ARGB.color(ARGB.as8BitChannel(f * g), (int)integer);
                }
                return integer;
            }
            if (this.drawShadow) {
                return ARGB.scaleRGB(i, 0.25f);
            }
            return 0;
        }

        @Override
        @Nullable
        public ScreenRectangle bounds() {
            if (this.left >= this.right || this.top >= this.bottom) {
                return null;
            }
            int i = Mth.floor(this.left);
            int j = Mth.floor(this.top);
            int k = Mth.ceil(this.right);
            int l = Mth.ceil(this.bottom);
            return new ScreenRectangle(i, j, k - i, l - j);
        }
    }
}

