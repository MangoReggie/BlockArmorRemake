/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package com.mojang.math;

import com.mojang.math.FieldsAreNonnullByDefault;
import com.mojang.math.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;


