/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.client.gui.components;

import com.google.common.collect.Lists;
import com.mojang.logging.LogUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.ChatFormatting;
import net.minecraft.Optionull;
import net.minecraft.client.GuiMessage;
import net.minecraft.client.GuiMessageTag;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ComponentRenderUtils;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.multiplayer.chat.ChatListener;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MessageSignature;
import net.minecraft.network.chat.Style;
import net.minecraft.util.ARGB;
import net.minecraft.util.ArrayListDeque;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.minecraft.util.profiling.Profiler;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.world.entity.player.ChatVisiblity;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

@Environment(value=EnvType.CLIENT)
public class ChatComponent {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final int MAX_CHAT_HISTORY = 100;
    private static final int MESSAGE_NOT_FOUND = -1;
    private static final int MESSAGE_INDENT = 4;
    private static final int MESSAGE_TAG_MARGIN_LEFT = 4;
    private static final int BOTTOM_MARGIN = 40;
    private static final int TIME_BEFORE_MESSAGE_DELETION = 60;
    private static final Component DELETED_CHAT_MESSAGE = Component.translatable("chat.deleted_marker").withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC);
    private final Minecraft minecraft;
    private final ArrayListDeque<String> recentChat = new ArrayListDeque(100);
    private final List<GuiMessage> allMessages = Lists.newArrayList();
    private final List<GuiMessage.Line> trimmedMessages = Lists.newArrayList();
    private int chatScrollbarPos;
    private boolean newMessageSinceScroll;
    private final List<DelayedMessageDeletion> messageDeletionQueue = new ArrayList<DelayedMessageDeletion>();

    public ChatComponent(Minecraft minecraft) {
        this.minecraft = minecraft;
        this.recentChat.addAll(minecraft.commandHistory().history());
    }

    public void tick() {
        if (!this.messageDeletionQueue.isEmpty()) {
            this.processMessageDeletionQueue();
        }
    }

    private int forEachLine(int i, int j, boolean bl, int k, LineConsumer lineConsumer) {
        int l = this.getLineHeight();
        int m = 0;
        for (int n = Math.min(this.trimmedMessages.size() - this.chatScrollbarPos, i) - 1; n >= 0; --n) {
            float f;
            int o = n + this.chatScrollbarPos;
            GuiMessage.Line line = this.trimmedMessages.get(o);
            if (line == null) continue;
            int p = j - line.addedTime();
            float f2 = f = bl ? 1.0f : (float)ChatComponent.getTimeFactor(p);
            if (!(f > 1.0E-5f)) continue;
            ++m;
            int q = k - n * l;
            int r = q - l;
            lineConsumer.accept(0, r, q, line, n, f);
        }
        return m;
    }

    public void render(GuiGraphics guiGraphics, int i, int j2, int k2, boolean bl) {
        int v;
        int u;
        if (this.isChatHidden()) {
            return;
        }
        int l2 = this.getLinesPerPage();
        int m2 = this.trimmedMessages.size();
        if (m2 <= 0) {
            return;
        }
        ProfilerFiller profilerFiller = Profiler.get();
        profilerFiller.push("chat");
        float f = (float)this.getScale();
        int n2 = Mth.ceil((float)this.getWidth() / f);
        int o2 = guiGraphics.guiHeight();
        guiGraphics.pose().pushMatrix();
        guiGraphics.pose().scale(f, f);
        guiGraphics.pose().translate(4.0f, 0.0f);
        int p = Mth.floor((float)(o2 - 40) / f);
        int q = this.getMessageEndIndexAt(this.screenToChatX(j2), this.screenToChatY(k2));
        float g2 = this.minecraft.options.chatOpacity().get().floatValue() * 0.9f + 0.1f;
        float h2 = this.minecraft.options.textBackgroundOpacity().get().floatValue();
        double d = this.minecraft.options.chatLineSpacing().get();
        int r = (int)Math.round(-8.0 * (d + 1.0) + 4.0 * d);
        this.forEachLine(l2, i, bl, p, (l, m, n, line, o, h) -> {
            guiGraphics.fill(l - 4, m, l + n2 + 4 + 4, n, ARGB.color(h * h2, -16777216));
            GuiMessageTag guiMessageTag = line.tag();
            if (guiMessageTag != null) {
                int p = ARGB.color(h * g2, guiMessageTag.indicatorColor());
                guiGraphics.fill(l - 4, m, l - 2, n, p);
                if (o == q && guiMessageTag.icon() != null) {
                    int q = this.getTagIconLeft(line);
                    int r = n + r + this.minecraft.font.lineHeight;
                    this.drawTagIcon(guiGraphics, q, r, guiMessageTag.icon());
                }
            }
        });
        int s = this.forEachLine(l2, i, bl, p, (j, k, l, line, m, g) -> {
            int n = l + r;
            guiGraphics.drawString(this.minecraft.font, line.content(), j, n, ARGB.color(g * g2, -1));
        });
        long t = this.minecraft.getChatListener().queueSize();
        if (t > 0L) {
            u = (int)(128.0f * g2);
            v = (int)(255.0f * h2);
            guiGraphics.pose().pushMatrix();
            guiGraphics.pose().translate(0.0f, p);
            guiGraphics.fill(-2, 0, n2 + 4, 9, v << 24);
            guiGraphics.drawString(this.minecraft.font, Component.translatable("chat.queue", t), 0, 1, ARGB.color(u, -1));
            guiGraphics.pose().popMatrix();
        }
        if (bl) {
            u = this.getLineHeight();
            v = m2 * u;
            int w = s * u;
            int x = this.chatScrollbarPos * w / m2 - p;
            int y = w * w / v;
            if (v != w) {
                int z = x > 0 ? 170 : 96;
                int aa = this.newMessageSinceScroll ? 0xCC3333 : 0x3333AA;
                int ab = n2 + 4;
                guiGraphics.fill(ab, -x, ab + 2, -x - y, ARGB.color(z, aa));
                guiGraphics.fill(ab + 2, -x, ab + 1, -x - y, ARGB.color(z, 0xCCCCCC));
            }
        }
        guiGraphics.pose().popMatrix();
        profilerFiller.pop();
    }

    private void drawTagIcon(GuiGraphics guiGraphics, int i, int j, GuiMessageTag.Icon icon) {
        int k = j - icon.height - 1;
        icon.draw(guiGraphics, i, k);
    }

    private int getTagIconLeft(GuiMessage.Line line) {
        return this.minecraft.font.width(line.content()) + 4;
    }

    private boolean isChatHidden() {
        return this.minecraft.options.chatVisibility().get() == ChatVisiblity.HIDDEN;
    }

    private static double getTimeFactor(int i) {
        double d = (double)i / 200.0;
        d = 1.0 - d;
        d *= 10.0;
        d = Mth.clamp(d, 0.0, 1.0);
        d *= d;
        return d;
    }

    public void clearMessages(boolean bl) {
        this.minecraft.getChatListener().clearQueue();
        this.messageDeletionQueue.clear();
        this.trimmedMessages.clear();
        this.allMessages.clear();
        if (bl) {
            this.recentChat.clear();
            this.recentChat.addAll(this.minecraft.commandHistory().history());
        }
    }

    public void addMessage(Component component) {
        this.addMessage(component, null, this.minecraft.isSingleplayer() ? GuiMessageTag.systemSinglePlayer() : GuiMessageTag.system());
    }

    public void addMessage(Component component, @Nullable MessageSignature messageSignature, @Nullable GuiMessageTag guiMessageTag) {
        GuiMessage guiMessage = new GuiMessage(this.minecraft.gui.getGuiTicks(), component, messageSignature, guiMessageTag);
        this.logChatMessage(guiMessage);
        this.addMessageToDisplayQueue(guiMessage);
        this.addMessageToQueue(guiMessage);
    }

    private void logChatMessage(GuiMessage guiMessage) {
        String string = guiMessage.content().getString().replaceAll("\r", "\\\\r").replaceAll("\n", "\\\\n");
        String string2 = Optionull.map(guiMessage.tag(), GuiMessageTag::logTag);
        if (string2 != null) {
            LOGGER.info("[{}] [CHAT] {}", (Object)string2, (Object)string);
        } else {
            LOGGER.info("[CHAT] {}", (Object)string);
        }
    }

    private void addMessageToDisplayQueue(GuiMessage guiMessage) {
        int i = Mth.floor((double)this.getWidth() / this.getScale());
        GuiMessageTag.Icon icon = guiMessage.icon();
        if (icon != null) {
            i -= icon.width + 4 + 2;
        }
        List<FormattedCharSequence> list = ComponentRenderUtils.wrapComponents(guiMessage.content(), i, this.minecraft.font);
        boolean bl = this.isChatFocused();
        for (int j = 0; j < list.size(); ++j) {
            FormattedCharSequence formattedCharSequence = list.get(j);
            if (bl && this.chatScrollbarPos > 0) {
                this.newMessageSinceScroll = true;
                this.scrollChat(1);
            }
            boolean bl2 = j == list.size() - 1;
            this.trimmedMessages.add(0, new GuiMessage.Line(guiMessage.addedTime(), formattedCharSequence, guiMessage.tag(), bl2));
        }
        while (this.trimmedMessages.size() > 100) {
            this.trimmedMessages.remove(this.trimmedMessages.size() - 1);
        }
    }

    private void addMessageToQueue(GuiMessage guiMessage) {
        this.allMessages.add(0, guiMessage);
        while (this.allMessages.size() > 100) {
            this.allMessages.remove(this.allMessages.size() - 1);
        }
    }

    private void processMessageDeletionQueue() {
        int i = this.minecraft.gui.getGuiTicks();
        this.messageDeletionQueue.removeIf(delayedMessageDeletion -> {
            if (i >= delayedMessageDeletion.deletableAfter()) {
                return this.deleteMessageOrDelay(delayedMessageDeletion.signature()) == null;
            }
            return false;
        });
    }

    public void deleteMessage(MessageSignature messageSignature) {
        DelayedMessageDeletion delayedMessageDeletion = this.deleteMessageOrDelay(messageSignature);
        if (delayedMessageDeletion != null) {
            this.messageDeletionQueue.add(delayedMessageDeletion);
        }
    }

    @Nullable
    private DelayedMessageDeletion deleteMessageOrDelay(MessageSignature messageSignature) {
        int i = this.minecraft.gui.getGuiTicks();
        ListIterator<GuiMessage> listIterator = this.allMessages.listIterator();
        while (listIterator.hasNext()) {
            GuiMessage guiMessage = listIterator.next();
            if (!messageSignature.equals(guiMessage.signature())) continue;
            int j = guiMessage.addedTime() + 60;
            if (i >= j) {
                listIterator.set(this.createDeletedMarker(guiMessage));
                this.refreshTrimmedMessages();
                return null;
            }
            return new DelayedMessageDeletion(messageSignature, j);
        }
        return null;
    }

    private GuiMessage createDeletedMarker(GuiMessage guiMessage) {
        return new GuiMessage(guiMessage.addedTime(), DELETED_CHAT_MESSAGE, null, GuiMessageTag.system());
    }

    public void rescaleChat() {
        this.resetChatScroll();
        this.refreshTrimmedMessages();
    }

    private void refreshTrimmedMessages() {
        this.trimmedMessages.clear();
        for (GuiMessage guiMessage : Lists.reverse(this.allMessages)) {
            this.addMessageToDisplayQueue(guiMessage);
        }
    }

    public ArrayListDeque<String> getRecentChat() {
        return this.recentChat;
    }

    public void addRecentChat(String string) {
        if (!string.equals(this.recentChat.peekLast())) {
            if (this.recentChat.size() >= 100) {
                this.recentChat.removeFirst();
            }
            this.recentChat.addLast(string);
        }
        if (string.startsWith("/")) {
            this.minecraft.commandHistory().addCommand(string);
        }
    }

    public void resetChatScroll() {
        this.chatScrollbarPos = 0;
        this.newMessageSinceScroll = false;
    }

    public void scrollChat(int i) {
        this.chatScrollbarPos += i;
        int j = this.trimmedMessages.size();
        if (this.chatScrollbarPos > j - this.getLinesPerPage()) {
            this.chatScrollbarPos = j - this.getLinesPerPage();
        }
        if (this.chatScrollbarPos <= 0) {
            this.chatScrollbarPos = 0;
            this.newMessageSinceScroll = false;
        }
    }

    public boolean handleChatQueueClicked(double d, double e) {
        if (!this.isChatFocused() || this.minecraft.options.hideGui || this.isChatHidden()) {
            return false;
        }
        ChatListener chatListener = this.minecraft.getChatListener();
        if (chatListener.queueSize() == 0L) {
            return false;
        }
        double f = d - 2.0;
        double g = (double)this.minecraft.getWindow().getGuiScaledHeight() - e - 40.0;
        if (f <= (double)Mth.floor((double)this.getWidth() / this.getScale()) && g < 0.0 && g > (double)Mth.floor(-9.0 * this.getScale())) {
            chatListener.acceptNextDelayedMessage();
            return true;
        }
        return false;
    }

    @Nullable
    public Style getClickedComponentStyleAt(double d, double e) {
        double g;
        double f = this.screenToChatX(d);
        int i = this.getMessageLineIndexAt(f, g = this.screenToChatY(e));
        if (i >= 0 && i < this.trimmedMessages.size()) {
            GuiMessage.Line line = this.trimmedMessages.get(i);
            return this.minecraft.font.getSplitter().componentStyleAtWidth(line.content(), Mth.floor(f));
        }
        return null;
    }

    @Nullable
    public GuiMessageTag getMessageTagAt(double d, double e) {
        GuiMessage.Line line;
        GuiMessageTag guiMessageTag;
        double g;
        double f = this.screenToChatX(d);
        int i = this.getMessageEndIndexAt(f, g = this.screenToChatY(e));
        if (i >= 0 && i < this.trimmedMessages.size() && (guiMessageTag = (line = this.trimmedMessages.get(i)).tag()) != null && this.hasSelectedMessageTag(f, line, guiMessageTag)) {
            return guiMessageTag;
        }
        return null;
    }

    private boolean hasSelectedMessageTag(double d, GuiMessage.Line line, GuiMessageTag guiMessageTag) {
        if (d < 0.0) {
            return true;
        }
        GuiMessageTag.Icon icon = guiMessageTag.icon();
        if (icon != null) {
            int i = this.getTagIconLeft(line);
            int j = i + icon.width;
            return d >= (double)i && d <= (double)j;
        }
        return false;
    }

    private double screenToChatX(double d) {
        return d / this.getScale() - 4.0;
    }

    private double screenToChatY(double d) {
        double e = (double)this.minecraft.getWindow().getGuiScaledHeight() - d - 40.0;
        return e / (this.getScale() * (double)this.getLineHeight());
    }

    private int getMessageEndIndexAt(double d, double e) {
        int i = this.getMessageLineIndexAt(d, e);
        if (i == -1) {
            return -1;
        }
        while (i >= 0) {
            if (this.trimmedMessages.get(i).endOfEntry()) {
                return i;
            }
            --i;
        }
        return i;
    }

    private int getMessageLineIndexAt(double d, double e) {
        int j;
        if (!this.isChatFocused() || this.isChatHidden()) {
            return -1;
        }
        if (d < -4.0 || d > (double)Mth.floor((double)this.getWidth() / this.getScale())) {
            return -1;
        }
        int i = Math.min(this.getLinesPerPage(), this.trimmedMessages.size());
        if (e >= 0.0 && e < (double)i && (j = Mth.floor(e + (double)this.chatScrollbarPos)) >= 0 && j < this.trimmedMessages.size()) {
            return j;
        }
        return -1;
    }

    public boolean isChatFocused() {
        return this.minecraft.screen instanceof ChatScreen;
    }

    public int getWidth() {
        return ChatComponent.getWidth(this.minecraft.options.chatWidth().get());
    }

    public int getHeight() {
        return ChatComponent.getHeight(this.isChatFocused() ? this.minecraft.options.chatHeightFocused().get() : this.minecraft.options.chatHeightUnfocused().get());
    }

    public double getScale() {
        return this.minecraft.options.chatScale().get();
    }

    public static int getWidth(double d) {
        int i = 320;
        int j = 40;
        return Mth.floor(d * 280.0 + 40.0);
    }

    public static int getHeight(double d) {
        int i = 180;
        int j = 20;
        return Mth.floor(d * 160.0 + 20.0);
    }

    public static double defaultUnfocusedPct() {
        int i = 180;
        int j = 20;
        return 70.0 / (double)(ChatComponent.getHeight(1.0) - 20);
    }

    public int getLinesPerPage() {
        return this.getHeight() / this.getLineHeight();
    }

    private int getLineHeight() {
        return (int)((double)this.minecraft.font.lineHeight * (this.minecraft.options.chatLineSpacing().get() + 1.0));
    }

    public State storeState() {
        return new State(List.copyOf(this.allMessages), List.copyOf(this.recentChat), List.copyOf(this.messageDeletionQueue));
    }

    public void restoreState(State state) {
        this.recentChat.clear();
        this.recentChat.addAll(state.history);
        this.messageDeletionQueue.clear();
        this.messageDeletionQueue.addAll(state.delayedMessageDeletions);
        this.allMessages.clear();
        this.allMessages.addAll(state.messages);
        this.refreshTrimmedMessages();
    }

    @FunctionalInterface
    @Environment(value=EnvType.CLIENT)
    static interface LineConsumer {
        public void accept(int var1, int var2, int var3, GuiMessage.Line var4, int var5, float var6);
    }

    @Environment(value=EnvType.CLIENT)
    record DelayedMessageDeletion(MessageSignature signature, int deletableAfter) {
    }

    @Environment(value=EnvType.CLIENT)
    public static class State {
        final List<GuiMessage> messages;
        final List<String> history;
        final List<DelayedMessageDeletion> delayedMessageDeletions;

        public State(List<GuiMessage> list, List<String> list2, List<DelayedMessageDeletion> list3) {
            this.messages = list;
            this.history = list2;
            this.delayedMessageDeletions = list3;
        }
    }
}

