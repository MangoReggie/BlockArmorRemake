/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@Environment(value=EnvType.CLIENT)
package com.mojang.realmsclient.dto;

import javax.annotation.ParametersAreNonnullByDefault;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.MethodsReturnNonnullByDefault;


