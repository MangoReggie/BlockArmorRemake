/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.client.data.models;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.renderer.item.ItemModel;
import net.minecraft.world.item.Item;

@Environment(value=EnvType.CLIENT)
public interface ItemModelOutput {
    public void accept(Item var1, ItemModel.Unbaked var2);

    public void copy(Item var1, Item var2);
}

