/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.realmsclient.dto;

import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import com.mojang.logging.LogUtils;
import java.io.IOException;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

@Environment(value=EnvType.CLIENT)
public enum ServiceQuality {
    GREAT(1, "icon/ping_5"),
    GOOD(2, "icon/ping_4"),
    OKAY(3, "icon/ping_3"),
    POOR(4, "icon/ping_2"),
    UNKNOWN(5, "icon/ping_unknown");

    final int value;
    private final ResourceLocation icon;

    private ServiceQuality(int j, String string2) {
        this.value = j;
        this.icon = ResourceLocation.withDefaultNamespace(string2);
    }

    @Nullable
    public static ServiceQuality byValue(int i) {
        for (ServiceQuality serviceQuality : ServiceQuality.values()) {
            if (serviceQuality.getValue() != i) continue;
            return serviceQuality;
        }
        return null;
    }

    public int getValue() {
        return this.value;
    }

    public ResourceLocation getIcon() {
        return this.icon;
    }

    @Environment(value=EnvType.CLIENT)
    public static class RealmsServiceQualityJsonAdapter
    extends TypeAdapter<ServiceQuality> {
        private static final Logger LOGGER = LogUtils.getLogger();

        @Override
        public void write(JsonWriter jsonWriter, ServiceQuality serviceQuality) throws IOException {
            jsonWriter.value(serviceQuality.value);
        }

        @Override
        public ServiceQuality read(JsonReader jsonReader) throws IOException {
            int i = jsonReader.nextInt();
            ServiceQuality serviceQuality = ServiceQuality.byValue(i);
            if (serviceQuality == null) {
                LOGGER.warn("Unsupported ServiceQuality {}", (Object)i);
                return UNKNOWN;
            }
            return serviceQuality;
        }

        @Override
        public /* synthetic */ Object read(JsonReader jsonReader) throws IOException {
            return this.read(jsonReader);
        }

        @Override
        public /* synthetic */ void write(JsonWriter jsonWriter, Object object) throws IOException {
            this.write(jsonWriter, (ServiceQuality)((Object)object));
        }
    }
}

