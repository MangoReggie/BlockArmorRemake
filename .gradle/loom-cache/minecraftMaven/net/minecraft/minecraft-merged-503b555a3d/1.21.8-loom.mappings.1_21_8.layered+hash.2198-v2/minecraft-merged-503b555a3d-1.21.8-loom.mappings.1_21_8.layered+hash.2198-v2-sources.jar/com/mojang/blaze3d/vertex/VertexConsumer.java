/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.blaze3d.vertex;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.util.ARGB;
import org.joml.Matrix3x2f;
import org.joml.Matrix4f;
import org.joml.Vector2f;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import org.lwjgl.system.MemoryStack;

@Environment(value=EnvType.CLIENT)
public interface VertexConsumer {
    public VertexConsumer addVertex(float var1, float var2, float var3);

    public VertexConsumer setColor(int var1, int var2, int var3, int var4);

    public VertexConsumer setUv(float var1, float var2);

    public VertexConsumer setUv1(int var1, int var2);

    public VertexConsumer setUv2(int var1, int var2);

    public VertexConsumer setNormal(float var1, float var2, float var3);

    default public void addVertex(float f, float g, float h, int i, float j, float k, int l, int m, float n, float o, float p) {
        this.addVertex(f, g, h);
        this.setColor(i);
        this.setUv(j, k);
        this.setOverlay(l);
        this.setLight(m);
        this.setNormal(n, o, p);
    }

    default public VertexConsumer setColor(float f, float g, float h, float i) {
        return this.setColor((int)(f * 255.0f), (int)(g * 255.0f), (int)(h * 255.0f), (int)(i * 255.0f));
    }

    default public VertexConsumer setColor(int i) {
        return this.setColor(ARGB.red(i), ARGB.green(i), ARGB.blue(i), ARGB.alpha(i));
    }

    default public VertexConsumer setWhiteAlpha(int i) {
        return this.setColor(ARGB.color(i, -1));
    }

    default public VertexConsumer setLight(int i) {
        return this.setUv2(i & 0xFFFF, i >> 16 & 0xFFFF);
    }

    default public VertexConsumer setOverlay(int i) {
        return this.setUv1(i & 0xFFFF, i >> 16 & 0xFFFF);
    }

    default public void putBulkData(PoseStack.Pose pose, BakedQuad bakedQuad, float f, float g, float h, float i, int j, int k) {
        this.putBulkData(pose, bakedQuad, new float[]{1.0f, 1.0f, 1.0f, 1.0f}, f, g, h, i, new int[]{j, j, j, j}, k, false);
    }

    default public void putBulkData(PoseStack.Pose pose, BakedQuad bakedQuad, float[] fs, float f, float g, float h, float i, int[] is, int j, boolean bl) {
        int[] js = bakedQuad.vertices();
        Vector3fc vector3fc = bakedQuad.direction().getUnitVec3f();
        Matrix4f matrix4f = pose.pose();
        Vector3f vector3f = pose.transformNormal(vector3fc, new Vector3f());
        int k = 8;
        int l = js.length / 8;
        int m = (int)(i * 255.0f);
        int n = bakedQuad.lightEmission();
        try (MemoryStack memoryStack = MemoryStack.stackPush();){
            ByteBuffer byteBuffer = memoryStack.malloc(DefaultVertexFormat.BLOCK.getVertexSize());
            IntBuffer intBuffer = byteBuffer.asIntBuffer();
            for (int o = 0; o < l; ++o) {
                float x;
                float w;
                float v;
                float u;
                intBuffer.clear();
                intBuffer.put(js, o * 8, 8);
                float p = byteBuffer.getFloat(0);
                float q = byteBuffer.getFloat(4);
                float r = byteBuffer.getFloat(8);
                if (bl) {
                    float s = byteBuffer.get(12) & 0xFF;
                    float t = byteBuffer.get(13) & 0xFF;
                    u = byteBuffer.get(14) & 0xFF;
                    v = s * fs[o] * f;
                    w = t * fs[o] * g;
                    x = u * fs[o] * h;
                } else {
                    v = fs[o] * f * 255.0f;
                    w = fs[o] * g * 255.0f;
                    x = fs[o] * h * 255.0f;
                }
                int y = ARGB.color(m, (int)v, (int)w, (int)x);
                int z = LightTexture.lightCoordsWithEmission(is[o], n);
                u = byteBuffer.getFloat(16);
                float aa = byteBuffer.getFloat(20);
                Vector3f vector3f2 = matrix4f.transformPosition(p, q, r, new Vector3f());
                this.addVertex(vector3f2.x(), vector3f2.y(), vector3f2.z(), y, u, aa, j, z, vector3f.x(), vector3f.y(), vector3f.z());
            }
        }
    }

    default public VertexConsumer addVertex(Vector3f vector3f) {
        return this.addVertex(vector3f.x(), vector3f.y(), vector3f.z());
    }

    default public VertexConsumer addVertex(PoseStack.Pose pose, Vector3f vector3f) {
        return this.addVertex(pose, vector3f.x(), vector3f.y(), vector3f.z());
    }

    default public VertexConsumer addVertex(PoseStack.Pose pose, float f, float g, float h) {
        return this.addVertex(pose.pose(), f, g, h);
    }

    default public VertexConsumer addVertex(Matrix4f matrix4f, float f, float g, float h) {
        Vector3f vector3f = matrix4f.transformPosition(f, g, h, new Vector3f());
        return this.addVertex(vector3f.x(), vector3f.y(), vector3f.z());
    }

    default public VertexConsumer addVertexWith2DPose(Matrix3x2f matrix3x2f, float f, float g, float h) {
        Vector2f vector2f = matrix3x2f.transformPosition(f, g, new Vector2f());
        return this.addVertex(vector2f.x(), vector2f.y(), h);
    }

    default public VertexConsumer setNormal(PoseStack.Pose pose, float f, float g, float h) {
        Vector3f vector3f = pose.transformNormal(f, g, h, new Vector3f());
        return this.setNormal(vector3f.x(), vector3f.y(), vector3f.z());
    }

    default public VertexConsumer setNormal(PoseStack.Pose pose, Vector3f vector3f) {
        return this.setNormal(pose, vector3f.x(), vector3f.y(), vector3f.z());
    }
}

