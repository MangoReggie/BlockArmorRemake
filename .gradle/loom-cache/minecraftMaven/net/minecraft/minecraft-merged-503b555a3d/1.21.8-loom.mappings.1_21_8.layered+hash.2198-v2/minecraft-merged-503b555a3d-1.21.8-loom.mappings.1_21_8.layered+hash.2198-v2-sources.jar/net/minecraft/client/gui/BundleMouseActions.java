/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.client.gui;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.ScrollWheelHandler;
import net.minecraft.client.gui.ItemSlotMouseAction;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ServerboundSelectBundleItemPacket;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.BundleItem;
import net.minecraft.world.item.ItemStack;
import org.joml.Vector2i;

@Environment(value=EnvType.CLIENT)
public class BundleMouseActions
implements ItemSlotMouseAction {
    private final Minecraft minecraft;
    private final ScrollWheelHandler scrollWheelHandler;

    public BundleMouseActions(Minecraft minecraft) {
        this.minecraft = minecraft;
        this.scrollWheelHandler = new ScrollWheelHandler();
    }

    @Override
    public boolean matches(Slot slot) {
        return slot.getItem().is(ItemTags.BUNDLES);
    }

    @Override
    public boolean onMouseScrolled(double d, double e, int i, ItemStack itemStack) {
        int m;
        int l;
        int k;
        int j = BundleItem.getNumberOfItemsToShow(itemStack);
        if (j == 0) {
            return false;
        }
        Vector2i vector2i = this.scrollWheelHandler.onMouseScroll(d, e);
        int n = k = vector2i.y == 0 ? -vector2i.x : vector2i.y;
        if (k != 0 && (l = BundleItem.getSelectedItem(itemStack)) != (m = ScrollWheelHandler.getNextScrollWheelSelection(k, l, j))) {
            this.toggleSelectedBundleItem(itemStack, i, m);
        }
        return true;
    }

    @Override
    public void onStopHovering(Slot slot) {
        this.unselectedBundleItem(slot.getItem(), slot.index);
    }

    @Override
    public void onSlotClicked(Slot slot, ClickType clickType) {
        if (clickType == ClickType.QUICK_MOVE || clickType == ClickType.SWAP) {
            this.unselectedBundleItem(slot.getItem(), slot.index);
        }
    }

    private void toggleSelectedBundleItem(ItemStack itemStack, int i, int j) {
        if (this.minecraft.getConnection() != null && j < BundleItem.getNumberOfItemsToShow(itemStack)) {
            ClientPacketListener clientPacketListener = this.minecraft.getConnection();
            BundleItem.toggleSelectedItem(itemStack, j);
            clientPacketListener.send(new ServerboundSelectBundleItemPacket(i, j));
        }
    }

    public void unselectedBundleItem(ItemStack itemStack, int i) {
        this.toggleSelectedBundleItem(itemStack, i, -1);
    }
}

