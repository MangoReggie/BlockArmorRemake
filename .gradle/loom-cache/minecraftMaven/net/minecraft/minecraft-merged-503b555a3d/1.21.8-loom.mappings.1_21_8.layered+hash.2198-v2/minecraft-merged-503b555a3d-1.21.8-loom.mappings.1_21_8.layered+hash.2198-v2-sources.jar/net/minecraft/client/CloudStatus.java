/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.client;

import com.mojang.serialization.Codec;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.OptionEnum;
import net.minecraft.util.StringRepresentable;

@Environment(value=EnvType.CLIENT)
public enum CloudStatus implements OptionEnum,
StringRepresentable
{
    OFF(0, "false", "options.off"),
    FAST(1, "fast", "options.clouds.fast"),
    FANCY(2, "true", "options.clouds.fancy");

    public static final Codec<CloudStatus> CODEC;
    private final int id;
    private final String legacyName;
    private final String key;

    private CloudStatus(int j, String string2, String string3) {
        this.id = j;
        this.legacyName = string2;
        this.key = string3;
    }

    @Override
    public String getSerializedName() {
        return this.legacyName;
    }

    @Override
    public int getId() {
        return this.id;
    }

    @Override
    public String getKey() {
        return this.key;
    }

    static {
        CODEC = StringRepresentable.fromEnum(CloudStatus::values);
    }
}

