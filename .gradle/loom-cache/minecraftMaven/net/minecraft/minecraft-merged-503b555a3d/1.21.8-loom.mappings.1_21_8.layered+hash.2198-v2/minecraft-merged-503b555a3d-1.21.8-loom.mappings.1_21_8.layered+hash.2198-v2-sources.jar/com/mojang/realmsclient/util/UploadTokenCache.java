/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.realmsclient.util;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jetbrains.annotations.Nullable;

@Environment(value=EnvType.CLIENT)
public class UploadTokenCache {
    private static final Long2ObjectMap<String> TOKEN_CACHE = new Long2ObjectOpenHashMap<String>();

    public static String get(long l) {
        return (String)TOKEN_CACHE.get(l);
    }

    public static void invalidate(long l) {
        TOKEN_CACHE.remove(l);
    }

    public static void put(long l, @Nullable String string) {
        TOKEN_CACHE.put(l, string);
    }
}

