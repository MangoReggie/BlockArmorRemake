/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.blaze3d.vertex;

import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormatElement;
import com.mojang.blaze3d.vertex.VertexSorting;
import it.unimi.dsi.fastutil.ints.IntConsumer;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.apache.commons.lang3.mutable.MutableLong;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;
import org.lwjgl.system.MemoryUtil;

@Environment(value=EnvType.CLIENT)
public class MeshData
implements AutoCloseable {
    private final ByteBufferBuilder.Result vertexBuffer;
    @Nullable
    private ByteBufferBuilder.Result indexBuffer;
    private final DrawState drawState;

    public MeshData(ByteBufferBuilder.Result result, DrawState drawState) {
        this.vertexBuffer = result;
        this.drawState = drawState;
    }

    private static Vector3f[] unpackQuadCentroids(ByteBuffer byteBuffer, int i, VertexFormat vertexFormat) {
        int j = vertexFormat.getOffset(VertexFormatElement.POSITION);
        if (j == -1) {
            throw new IllegalArgumentException("Cannot identify quad centers with no position element");
        }
        FloatBuffer floatBuffer = byteBuffer.asFloatBuffer();
        int k = vertexFormat.getVertexSize() / 4;
        int l = k * 4;
        int m = i / 4;
        Vector3f[] vector3fs = new Vector3f[m];
        for (int n = 0; n < m; ++n) {
            int o = n * l + j;
            int p = o + k * 2;
            float f = floatBuffer.get(o + 0);
            float g = floatBuffer.get(o + 1);
            float h = floatBuffer.get(o + 2);
            float q = floatBuffer.get(p + 0);
            float r = floatBuffer.get(p + 1);
            float s = floatBuffer.get(p + 2);
            vector3fs[n] = new Vector3f((f + q) / 2.0f, (g + r) / 2.0f, (h + s) / 2.0f);
        }
        return vector3fs;
    }

    public ByteBuffer vertexBuffer() {
        return this.vertexBuffer.byteBuffer();
    }

    @Nullable
    public ByteBuffer indexBuffer() {
        return this.indexBuffer != null ? this.indexBuffer.byteBuffer() : null;
    }

    public DrawState drawState() {
        return this.drawState;
    }

    @Nullable
    public SortState sortQuads(ByteBufferBuilder byteBufferBuilder, VertexSorting vertexSorting) {
        if (this.drawState.mode() != VertexFormat.Mode.QUADS) {
            return null;
        }
        Vector3f[] vector3fs = MeshData.unpackQuadCentroids(this.vertexBuffer.byteBuffer(), this.drawState.vertexCount(), this.drawState.format());
        SortState sortState = new SortState(vector3fs, this.drawState.indexType());
        this.indexBuffer = sortState.buildSortedIndexBuffer(byteBufferBuilder, vertexSorting);
        return sortState;
    }

    @Override
    public void close() {
        this.vertexBuffer.close();
        if (this.indexBuffer != null) {
            this.indexBuffer.close();
        }
    }

    @Environment(value=EnvType.CLIENT)
    public record DrawState(VertexFormat format, int vertexCount, int indexCount, VertexFormat.Mode mode, VertexFormat.IndexType indexType) {
    }

    @Environment(value=EnvType.CLIENT)
    public record SortState(Vector3f[] centroids, VertexFormat.IndexType indexType) {
        @Nullable
        public ByteBufferBuilder.Result buildSortedIndexBuffer(ByteBufferBuilder byteBufferBuilder, VertexSorting vertexSorting) {
            int[] is = vertexSorting.sort(this.centroids);
            long l = byteBufferBuilder.reserve(is.length * 6 * this.indexType.bytes);
            IntConsumer intConsumer = this.indexWriter(l, this.indexType);
            for (int i : is) {
                intConsumer.accept(i * 4 + 0);
                intConsumer.accept(i * 4 + 1);
                intConsumer.accept(i * 4 + 2);
                intConsumer.accept(i * 4 + 2);
                intConsumer.accept(i * 4 + 3);
                intConsumer.accept(i * 4 + 0);
            }
            return byteBufferBuilder.build();
        }

        private IntConsumer indexWriter(long l, VertexFormat.IndexType indexType) {
            MutableLong mutableLong = new MutableLong(l);
            return switch (indexType) {
                default -> throw new MatchException(null, null);
                case VertexFormat.IndexType.SHORT -> i -> MemoryUtil.memPutShort(mutableLong.getAndAdd(2L), (short)i);
                case VertexFormat.IndexType.INT -> i -> MemoryUtil.memPutInt(mutableLong.getAndAdd(4L), i);
            };
        }
    }
}

