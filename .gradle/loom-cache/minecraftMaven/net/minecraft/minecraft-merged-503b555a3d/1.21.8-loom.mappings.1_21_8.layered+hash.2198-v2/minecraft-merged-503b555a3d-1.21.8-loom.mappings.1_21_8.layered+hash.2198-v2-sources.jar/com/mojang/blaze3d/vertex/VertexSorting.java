/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.blaze3d.vertex;

import com.google.common.primitives.Floats;
import it.unimi.dsi.fastutil.ints.IntArrays;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.joml.Vector3f;

@Environment(value=EnvType.CLIENT)
public interface VertexSorting {
    public static final VertexSorting DISTANCE_TO_ORIGIN = VertexSorting.byDistance(0.0f, 0.0f, 0.0f);
    public static final VertexSorting ORTHOGRAPHIC_Z = VertexSorting.byDistance((Vector3f vector3f) -> -vector3f.z());

    public static VertexSorting byDistance(float f, float g, float h) {
        return VertexSorting.byDistance(new Vector3f(f, g, h));
    }

    public static VertexSorting byDistance(Vector3f vector3f) {
        return VertexSorting.byDistance(vector3f::distanceSquared);
    }

    public static VertexSorting byDistance(DistanceFunction distanceFunction) {
        return vector3fs -> {
            float[] fs = new float[vector3fs.length];
            int[] is = new int[vector3fs.length];
            for (int i2 = 0; i2 < vector3fs.length; ++i2) {
                fs[i2] = distanceFunction.apply(vector3fs[i2]);
                is[i2] = i2;
            }
            IntArrays.mergeSort(is, (i, j) -> Floats.compare(fs[j], fs[i]));
            return is;
        };
    }

    public int[] sort(Vector3f[] var1);

    @Environment(value=EnvType.CLIENT)
    public static interface DistanceFunction {
        public float apply(Vector3f var1);
    }
}

