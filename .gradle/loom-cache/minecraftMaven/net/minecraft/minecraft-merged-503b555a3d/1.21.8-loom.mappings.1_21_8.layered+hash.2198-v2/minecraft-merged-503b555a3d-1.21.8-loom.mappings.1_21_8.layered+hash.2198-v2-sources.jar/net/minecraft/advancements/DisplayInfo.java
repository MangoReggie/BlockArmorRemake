/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.advancements;

import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.advancements.AdvancementType;
import net.minecraft.core.ClientAsset;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.ItemStack;

public class DisplayInfo {
    public static final Codec<DisplayInfo> CODEC = RecordCodecBuilder.create(instance -> instance.group(((MapCodec)ItemStack.STRICT_CODEC.fieldOf("icon")).forGetter(DisplayInfo::getIcon), ((MapCodec)ComponentSerialization.CODEC.fieldOf("title")).forGetter(DisplayInfo::getTitle), ((MapCodec)ComponentSerialization.CODEC.fieldOf("description")).forGetter(DisplayInfo::getDescription), ClientAsset.CODEC.optionalFieldOf("background").forGetter(DisplayInfo::getBackground), AdvancementType.CODEC.optionalFieldOf("frame", AdvancementType.TASK).forGetter(DisplayInfo::getType), Codec.BOOL.optionalFieldOf("show_toast", true).forGetter(DisplayInfo::shouldShowToast), Codec.BOOL.optionalFieldOf("announce_to_chat", true).forGetter(DisplayInfo::shouldAnnounceChat), Codec.BOOL.optionalFieldOf("hidden", false).forGetter(DisplayInfo::isHidden)).apply((Applicative<DisplayInfo, ?>)instance, DisplayInfo::new));
    public static final StreamCodec<RegistryFriendlyByteBuf, DisplayInfo> STREAM_CODEC = StreamCodec.ofMember(DisplayInfo::serializeToNetwork, DisplayInfo::fromNetwork);
    private final Component title;
    private final Component description;
    private final ItemStack icon;
    private final Optional<ClientAsset> background;
    private final AdvancementType type;
    private final boolean showToast;
    private final boolean announceChat;
    private final boolean hidden;
    private float x;
    private float y;

    public DisplayInfo(ItemStack itemStack, Component component, Component component2, Optional<ClientAsset> optional, AdvancementType advancementType, boolean bl, boolean bl2, boolean bl3) {
        this.title = component;
        this.description = component2;
        this.icon = itemStack;
        this.background = optional;
        this.type = advancementType;
        this.showToast = bl;
        this.announceChat = bl2;
        this.hidden = bl3;
    }

    public void setLocation(float f, float g) {
        this.x = f;
        this.y = g;
    }

    public Component getTitle() {
        return this.title;
    }

    public Component getDescription() {
        return this.description;
    }

    public ItemStack getIcon() {
        return this.icon;
    }

    public Optional<ClientAsset> getBackground() {
        return this.background;
    }

    public AdvancementType getType() {
        return this.type;
    }

    public float getX() {
        return this.x;
    }

    public float getY() {
        return this.y;
    }

    public boolean shouldShowToast() {
        return this.showToast;
    }

    public boolean shouldAnnounceChat() {
        return this.announceChat;
    }

    public boolean isHidden() {
        return this.hidden;
    }

    private void serializeToNetwork(RegistryFriendlyByteBuf registryFriendlyByteBuf) {
        ComponentSerialization.TRUSTED_STREAM_CODEC.encode(registryFriendlyByteBuf, this.title);
        ComponentSerialization.TRUSTED_STREAM_CODEC.encode(registryFriendlyByteBuf, this.description);
        ItemStack.STREAM_CODEC.encode(registryFriendlyByteBuf, this.icon);
        registryFriendlyByteBuf.writeEnum(this.type);
        int i = 0;
        if (this.background.isPresent()) {
            i |= 1;
        }
        if (this.showToast) {
            i |= 2;
        }
        if (this.hidden) {
            i |= 4;
        }
        registryFriendlyByteBuf.writeInt(i);
        this.background.map(ClientAsset::id).ifPresent(registryFriendlyByteBuf::writeResourceLocation);
        registryFriendlyByteBuf.writeFloat(this.x);
        registryFriendlyByteBuf.writeFloat(this.y);
    }

    private static DisplayInfo fromNetwork(RegistryFriendlyByteBuf registryFriendlyByteBuf) {
        Component component = (Component)ComponentSerialization.TRUSTED_STREAM_CODEC.decode(registryFriendlyByteBuf);
        Component component2 = (Component)ComponentSerialization.TRUSTED_STREAM_CODEC.decode(registryFriendlyByteBuf);
        ItemStack itemStack = (ItemStack)ItemStack.STREAM_CODEC.decode(registryFriendlyByteBuf);
        AdvancementType advancementType = registryFriendlyByteBuf.readEnum(AdvancementType.class);
        int i = registryFriendlyByteBuf.readInt();
        Optional<ClientAsset> optional = (i & 1) != 0 ? Optional.of(new ClientAsset(registryFriendlyByteBuf.readResourceLocation())) : Optional.empty();
        boolean bl = (i & 2) != 0;
        boolean bl2 = (i & 4) != 0;
        DisplayInfo displayInfo = new DisplayInfo(itemStack, component, component2, optional, advancementType, bl, false, bl2);
        displayInfo.setLocation(registryFriendlyByteBuf.readFloat(), registryFriendlyByteBuf.readFloat());
        return displayInfo;
    }
}

