/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.client.color.item;

import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.color.item.ItemTintSource;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GrassColor;
import org.jetbrains.annotations.Nullable;

@Environment(value=EnvType.CLIENT)
public record GrassColorSource(float temperature, float downfall) implements ItemTintSource
{
    public static final MapCodec<GrassColorSource> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(((MapCodec)ExtraCodecs.floatRange(0.0f, 1.0f).fieldOf("temperature")).forGetter(GrassColorSource::temperature), ((MapCodec)ExtraCodecs.floatRange(0.0f, 1.0f).fieldOf("downfall")).forGetter(GrassColorSource::downfall)).apply((Applicative<GrassColorSource, ?>)instance, GrassColorSource::new));

    public GrassColorSource() {
        this(0.5f, 1.0f);
    }

    @Override
    public int calculate(ItemStack itemStack, @Nullable ClientLevel clientLevel, @Nullable LivingEntity livingEntity) {
        return GrassColor.get(this.temperature, this.downfall);
    }

    public MapCodec<GrassColorSource> type() {
        return MAP_CODEC;
    }
}

